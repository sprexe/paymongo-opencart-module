<?php echo $header; ?><?php echo $column_left; ?>

<div id="content">
  <ul class="breadcrumb">
    <?php foreach ($breadcrumbs as $breadcrumb) { ?>
    <li><a href="<?php echo $breadcrumb['href']; ?>"><?php echo $breadcrumb['text']; ?></a></li>
    <?php } ?>
  </ul>
  <div class="page-header">
    <div class="container-fluid">
      <div class="pull-right">
        <button type="submit" form="form-paymongo" data-toggle="tooltip" title="<?php echo $button_save; ?>" class="btn btn-primary"><i class="fa fa-save"></i></button>
        <a href="<?php echo $cancel; ?>" data-toggle="tooltip" title="<?php echo $button_cancel; ?>" class="btn btn-default"><i class="fa fa-reply"></i></a></div>
      <h1><i class="fa fa-credit-card"></i> <?php echo $heading_title; ?></h1>
    </div>
  </div>
  <div class="container-fluid">
    <div class="panel-body">
      <form action="<?php echo $action; ?>" method="post" enctype="multipart/form-data" id="form-paymongo" class="form-horizontal">
        <ul class="nav nav-tabs">
          <li class="active"><a href="#tab-general" data-toggle="tab"><?php echo $tab_settings; ?></a></li>
          <li><a href="#tab-card" data-toggle="tab"><?php echo $tab_card;?></a></li>
          <li><a href="#tab-gcash" data-toggle="tab"><?php echo $tab_gcash;?></a></li>
          <li><a href="#tab-grab_pay" data-toggle="tab"><?php echo $tab_grab_pay;?></a></li>
          <li><a href="#tab-paymaya" data-toggle="tab"><?php echo $tab_paymaya;?></a></li>
          <li><a href="#tab-atome" data-toggle="tab"><?php echo $tab_atome;?></a></li>
          <li><a href="#tab-billease" data-toggle="tab"><?php echo $tab_billease;?></a></li>
        </ul>
        <div class="tab-content">
          <div class="tab-pane active" id="tab-general">
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-paymongo_test_public_key"><?php echo $entry_test_public_key; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_test_public_key" value="<?php echo $paymongo_test_public_key; ?>" placeholder="<?php echo $entry_test_public_key; ?>" id="input-paymongo_test_public_key" class="form-control" />
                <?php if ($error_test_public_key) { ?>
                <div class="text-danger"><?php echo $error_test_public_key; ?></div>
                <?php } ?>
              </div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-paymongo_test_secret_key"><?php echo $entry_test_secret_key; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_test_secret_key" value="<?php echo $paymongo_test_secret_key; ?>" placeholder="<?php echo $entry_test_secret_key; ?>" id="input-paymongo_test_secret_key" class="form-control" />
                <?php if ($error_test_secret_key) { ?>
                <div class="text-danger"><?php echo $error_test_secret_key; ?></div>
                <?php } ?>
              </div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-paymongo_live_public_key"><?php echo $entry_live_public_key; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_live_public_key" value="<?php echo $paymongo_live_public_key; ?>" placeholder="<?php echo $entry_live_public_key; ?>" id="input-paymongo_live_public_key" class="form-control" />
                <?php if ($error_live_public_key) { ?>
                <div class="text-danger"><?php echo $error_live_public_key; ?></div>
                <?php } ?>
              </div>
            </div>
            <div class="form-group required">
              <label class="col-sm-2 control-label" for="input-paymongo_live_secret_key"><?php echo $entry_live_secret_key; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_live_secret_key" value="<?php echo $paymongo_live_secret_key; ?>" placeholder="<?php echo $entry_live_secret_key; ?>" id="input-paymongo_live_secret_key" class="form-control" />
                <?php if ($error_live_secret_key) { ?>
                <div class="text-danger"><?php echo $error_live_secret_key; ?></div>
                <?php } ?>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-test"><?php echo $entry_test; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_test" id="input-test" class="form-control">
                  <?php if ($paymongo_test == 'test') { ?>
                  <option value="test" selected="selected"><?php echo $text_test; ?></option>
                  <?php } else { ?>
                  <option value="test"><?php echo $text_test; ?></option>
                  <?php } ?>
                  <?php if ($paymongo_test == 'live') { ?>
                  <option value="live" selected="selected"><?php echo $text_live; ?></option>
                  <?php } else { ?>
                  <option value="live"><?php echo $text_live; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-order-status"><?php echo $entry_order_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_order_status_id" id="input-order-status" class="form-control">
                  <?php foreach ($order_statuses as $order_status) { ?>
                  <?php if ($order_status['order_status_id'] == $paymongo_order_status_id) { ?>
                  <option value="<?php echo $order_status['order_status_id']; ?>" selected="selected"><?php echo $order_status['name']; ?></option>
                  <?php } else { ?>
                  <option value="<?php echo $order_status['order_status_id']; ?>"><?php echo $order_status['name']; ?></option>
                  <?php } ?>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-webhook"><span data-toggle="tooltip" title="<?php echo $help_webhook;?>"><?php echo $entry_webhook_url;?></span></label>
              <div class="col-sm-10">
                <?php if ($paymongo_webhook_url) {?>
                <input type="text" name="paymongo_webhook_url" value="<?php echo $paymongo_webhook_url;?>" placeholder="<?php echo $entry_webhook_url;?>" id="input-webhook_url" class="form-control" readonly />
                <?php } else {?>
                <button type="button" data-toggle="tooltip" onClick="generateWebhook();" title="" class="btn btn-primary" data-original-title="<?php echo $button_generatewebhookurl;?>"><?php echo $button_generatewebhookurl;?></button>
                <?php } ?>
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-card">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_status" id="input-status" class="form-control">
                  <?php if ($paymongo_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_sort_order" value="<?php echo $paymongo_sort_order; ?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-sort-order" class="form-control" />
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-gcash">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-gcash-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_gcash_status" id="input-gcash-status" class="form-control">
                  <?php if ($paymongo_gcash_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-gcash-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_gcash_sort_order" value="<?php echo $paymongo_gcash_sort_order;?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-gcash-sort-order" class="form-control" />
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-grab_pay">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-grab_pay-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_grab_pay_status" id="input-grab_pay-status" class="form-control">
                  <?php if ($paymongo_grab_pay_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-grab_pay-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_grab_pay_sort_order" value="<?php echo $paymongo_grab_pay_sort_order;?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-grab_pay-sort-order" class="form-control" />
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-paymaya">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-paymaya-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_paymaya_status" id="input-paymaya-status" class="form-control">
                  <?php if ($paymongo_paymaya_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-paymaya-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_paymaya_sort_order" value="<?php echo $paymongo_paymaya_sort_order;?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-paymaya-sort-order" class="form-control" />
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-atome">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-atome-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_atome_status" id="input-atome-status" class="form-control">
                  <?php if ($paymongo_atome_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-atome-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_atome_sort_order" value="<?php echo $paymongo_atome_sort_order;?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-atome-sort-order" class="form-control" />
              </div>
            </div>
          </div>
          <div class="tab-pane" id="tab-billease">
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-billease-status"><?php echo $entry_status; ?></label>
              <div class="col-sm-10">
                <select name="paymongo_billease_status" id="input-atome-status" class="form-control">
                  <?php if ($paymongo_billease_status) { ?>
                  <option value="1" selected="selected"><?php echo $text_enabled; ?></option>
                  <option value="0"><?php echo $text_disabled; ?></option>
                  <?php } else { ?>
                  <option value="1"><?php echo $text_enabled; ?></option>
                  <option value="0" selected="selected"><?php echo $text_disabled; ?></option>
                  <?php } ?>
                </select>
              </div>
            </div>
            <div class="form-group">
              <label class="col-sm-2 control-label" for="input-billease-sort-order"><?php echo $entry_sort_order; ?></label>
              <div class="col-sm-10">
                <input type="text" name="paymongo_billease_sort_order" value="<?php echo $paymongo_billease_sort_order;?>" placeholder="<?php echo $entry_sort_order; ?>" id="input-billease-sort-order" class="form-control" />
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<script>
function generateWebhook()
{
	var paymongo_test_public_key='<?php echo $paymongo_test_public_key;?>';
	var paymongo_test_secret_key='<?php echo $paymongo_test_secret_key;?>';
	var paymongo_live_public_key='<?php echo $paymongo_live_public_key;?>';
	var paymongo_live_secret_key='<?php echo $paymongo_live_secret_key;?>';
	if(paymongo_test_public_key=='' || paymongo_test_secret_key=='' || paymongo_live_public_key=='' || paymongo_live_secret_key=='')
	{
		 	alert("<?php echo $error_webhook_public_secret_key;?>");
	}
	else
	{
		      $.ajax({
			  url: 'index.php?route=extension/payment/paymongo/generateWebhook&token=<?php echo $token;?>',
			  dataType: 'json',
			  success: function(json) {
			  		if(json['error'])
					{
						alert(json['error']);
						
					}
					if(json['success'])
					{
						 alert(json['success']);
						 location.reload();
						
					}
			  }
		  });	
	}
}
</script>
<?php echo $footer; ?>