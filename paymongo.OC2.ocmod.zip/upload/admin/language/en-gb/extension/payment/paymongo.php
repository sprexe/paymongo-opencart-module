<?php
// Heading
$_['heading_title']				         = 'Paymongo Online Payments';

// Text
$_['text_extension']				     = 'Extensions';
$_['text_success']				         = 'Success: You have modified paymongo account details!';
$_['text_paymongo']				         = '<a href="https://online.paymongo.com/signup/ee48b6e6-d3e3-42aa-a80e-cbee3f4f8b09" target="_blank"><img src="view/image/payment/paymongo-green.png" alt="paymongo" title="paymongo" style="border: 1px solid #EEEEEE; width:108px;" /></a>';
$_['text_test']					         = 'Test';
$_['text_live']					         = 'Live';
$_['entry_test']			  = 'Test Mode';
$_['text_authenticate']			         = 'Authenticate';
$_['text_release_ok']		 	         = 'Release was successful';
$_['text_release_ok_order']		         = 'Release was successful, order status updated to success - settled';
$_['text_refund_ok']			         = 'Rebate was successful';
$_['text_refund_ok_order']		         = 'Rebate was successful, order status updated to refund';
$_['text_void_ok']				         = 'Void was successful, order status updated to voided';

// Entry
$_['entry_test_public_key']			         = 'Test Public Key';
$_['entry_test_secret_key']			         = 'Test Secret Key';
$_['entry_live_public_key']			         = 'Live Public Key';
$_['entry_live_secret_key']			         = 'Live Secret Key';

$_['entry_service_key']			         = 'Service Key';
$_['entry_client_key']			         = 'Client Key';
$_['entry_total']				         = 'Total';
$_['entry_order_status']		         = 'Order Status';
$_['entry_geo_zone']			         = 'Geo Zone';
$_['entry_status']				         = 'Status';
$_['entry_sort_order']			         = 'Sort Order';
$_['entry_debug']				         = 'Debug logging';
$_['entry_card']				         = 'Store Cards';
$_['entry_secret_token']		         = 'Secret Token';
$_['entry_webhook_url']			         = 'Webhook URL:';
$_['entry_cron_job_url']		         = 'Cron Job URL:';
$_['entry_last_cron_job_run']	         = 'Last cron job\'s run time:';
$_['entry_success_status']		         = 'Success Status:';
$_['entry_failed_status']		         = 'Failed Status:';
$_['entry_settled_status']			     = 'Settled Status:';
$_['entry_refunded_status']			     = 'Refunded Status:';
$_['entry_partially_refunded_status']	 = 'Partially Refunded Status:';
$_['entry_charged_back_status']			 = 'Charged Back:';
$_['entry_information_requested_status'] = 'Information Requested Status:';
$_['entry_information_supplied_status']	 = 'Information Supplied Status:';
$_['entry_chargeback_reversed_status']	 = 'Chargeback Reversed Status:';


$_['entry_reversed_status']			     = 'Reversed Status:';
$_['entry_voided_status']			     = 'Voided Status:';

// Error
$_['error_permission']			         = 'Warning: You do not have permission to modify payment paymongo!';
$_['error_service_key']			         = 'Service Key Required!';
$_['error_test_public_key']			         = 'Test Public Key Required!';
$_['error_test_secret_key']			         = 'Test Secret Key Required!';
$_['error_live_public_key']			         = 'Live Public Key Required!';
$_['error_live_secret_key']			         = 'Live Secret Key Required!';

// Order page - payment tab
$_['text_payment_info']			         = 'Payment information';
$_['text_refund_status']		         = 'Payment refund';
$_['text_order_ref']			         = 'Order ref';
$_['text_order_total']			         = 'Total authorised';
$_['text_total_released']		         = 'Total released';
$_['text_transactions']			         = 'Transactions';
$_['text_column_amount']		         = 'Amount';
$_['text_column_type']			         = 'Type';
$_['text_column_date_added']	         = 'Added';

$_['text_confirm_refund']		         = 'Are you sure you want to refund the payment?';

$_['button_refund']				         = 'Rebate / refund';

$_['tab_settings']				         = 'Common Settings';

//Addtional Paymongo Payment 
$_['tab_card']				         	 = 'Credit and Debit Card Payments';
$_['tab_gcash']				         	 = 'GCash payments';
$_['tab_grab_pay']				         = 'GrabPay payments';
$_['tab_paymaya']				         = 'Maya payments';
$_['tab_atome']				         	 = 'Atome payments';
$_['tab_billease']				         = 'BillEase payments';
//Addtional Paymongo Payment 


$_['text_webhook_url_generated']	     = 'Webhook Url Successfully Generated';
$_['entry_webhook_url']			         = 'Webhook URL';
$_['button_generatewebhookurl']          = 'Generate Webhook URL';
// Help
$_['help_webhook']        				 = 'Webhook URL must be compulsory for Gcash and GrabPay Payment, Without Webhook URL Gcash and GrabPay payment did not completed. This Webhook URL only work once website on domain/live';
//Error
$_['error_webhook_public_secret_key']="You must save Public Key & Secret Key before generated Webhook";
$_['error_curl']="cURL Error #:";