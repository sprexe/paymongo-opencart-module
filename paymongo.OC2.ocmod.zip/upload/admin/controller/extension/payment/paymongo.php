<?php
class ControllerExtensionPaymentPaymongo extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/paymongo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$paymongo=array();
			$paymongo['paymongo_test_public_key']=$this->request->post['paymongo_test_public_key'];
			$paymongo['paymongo_test_secret_key']=$this->request->post['paymongo_test_secret_key'];
			$paymongo['paymongo_live_public_key']=$this->request->post['paymongo_live_public_key'];
			$paymongo['paymongo_live_secret_key']=$this->request->post['paymongo_live_secret_key'];
			$paymongo['paymongo_test']=$this->request->post['paymongo_test'];
			$paymongo['paymongo_order_status_id']=$this->request->post['paymongo_order_status_id'];
			$paymongo['paymongo_status']=$this->request->post['paymongo_status'];
			$paymongo['paymongo_sort_order']=$this->request->post['paymongo_sort_order'];
			
			$this->model_setting_setting->editSetting('paymongo', $this->request->post);
			
			//Addtional Payment Paymongo
			$paymongo_gcash=array();
			$paymongo_gcash['paymongo_gcash_status']=$this->request->post['paymongo_gcash_status'];
			$paymongo_gcash['paymongo_gcash_sort_order']=$this->request->post['paymongo_gcash_sort_order'];
			$this->model_setting_setting->editSetting('paymongo_gcash', $paymongo_gcash);
			
			$paymongo_grab_pay=array();
			$paymongo_grab_pay['paymongo_grab_pay_status']=$this->request->post['paymongo_grab_pay_status'];
			$paymongo_grab_pay['paymongo_grab_pay_sort_order']=$this->request->post['paymongo_grab_pay_sort_order'];
			$this->model_setting_setting->editSetting('paymongo_grab_pay', $paymongo_grab_pay);
			
			$paymongo_paymaya=array();
			$paymongo_paymaya['paymongo_paymaya_status']=$this->request->post['paymongo_paymaya_status'];
			$paymongo_paymaya['paymongo_paymaya_sort_order']=$this->request->post['paymongo_paymaya_sort_order'];
			$this->model_setting_setting->editSetting('paymongo_paymaya', $paymongo_paymaya);
			
			$paymongo_atome=array();
			$paymongo_atome['paymongo_atome_status']=$this->request->post['paymongo_atome_status'];
			$paymongo_atome['paymongo_atome_sort_order']=$this->request->post['paymongo_atome_sort_order'];
			$this->model_setting_setting->editSetting('paymongo_atome', $paymongo_atome);
			
			$paymongo_billease=array();
			$paymongo_billease['paymongo_billease_status']=$this->request->post['paymongo_billease_status'];
			$paymongo_billease['paymongo_billease_sort_order']=$this->request->post['paymongo_billease_sort_order'];
			$this->model_setting_setting->editSetting('paymongo_billease', $paymongo_billease);
			//Addtional Payment Paymongo

			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true));
		}

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_test'] = $this->language->get('text_test');
		$data['text_live'] = $this->language->get('text_live');
		$data['text_payment'] = $this->language->get('text_payment');
		$data['text_test'] = $this->language->get('text_test');
		$data['text_live'] = $this->language->get('text_live');		
		$data['entry_test'] = $this->language->get('entry_test');
		$data['entry_test_public_key'] = $this->language->get('entry_test_public_key');
		$data['entry_test_secret_key'] = $this->language->get('entry_test_secret_key');		
		$data['entry_live_public_key'] = $this->language->get('entry_live_public_key');
		$data['entry_live_secret_key'] = $this->language->get('entry_live_secret_key');

		$data['entry_order_status'] = $this->language->get('entry_order_status');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_sort_order'] = $this->language->get('entry_sort_order');
		
		$data['entry_success_status'] = $this->language->get('entry_success_status');
		$data['entry_failed_status'] = $this->language->get('entry_failed_status');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		$data['tab_settings'] = $this->language->get('tab_settings');	
		
		$data['entry_webhook_url'] = $this->language->get('entry_webhook_url');
		$data['tab_card'] = $this->language->get('tab_card');
		$data['tab_gcash'] = $this->language->get('tab_gcash');
		$data['tab_grab_pay'] = $this->language->get('tab_grab_pay');
		$data['tab_paymaya'] = $this->language->get('tab_paymaya');
		$data['tab_atome'] = $this->language->get('tab_atome');
		$data['tab_billease'] = $this->language->get('tab_billease');
		$data['error_webhook_public_secret_key'] = $this->language->get('error_webhook_public_secret_key');
		$data['text_webhook_url_generated'] = $this->language->get('text_webhook_url_generated');
		$data['button_generatewebhookurl'] = $this->language->get('button_generatewebhookurl');
		$data['help_webhook'] = $this->language->get('help_webhook');
		
			

		if (isset($this->error['error_test_public_key'])) {
			$data['error_test_public_key'] = $this->error['error_test_public_key'];
		} else {
			$data['error_test_public_key'] = '';
		}

		if (isset($this->error['error_test_secret_key'])) {
			$data['error_test_secret_key'] = $this->error['error_test_secret_key'];
		} else {
			$data['error_test_secret_key'] = '';
		}
		
		if (isset($this->error['error_live_public_key'])) {
			$data['error_live_public_key'] = $this->error['error_live_public_key'];
		} else {
			$data['error_live_public_key'] = '';
		}

		if (isset($this->error['error_live_secret_key'])) {
			$data['error_live_secret_key'] = $this->error['error_live_secret_key'];
		} else {
			$data['error_live_secret_key'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/paymongo', 'token=' . $this->session->data['token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/paymongo', 'token=' . $this->session->data['token'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=payment', true);
		
		if (isset($this->request->post['paymongo_test'])) {
			$data['paymongo_test'] = $this->request->post['paymongo_test'];
		} else {
			$data['paymongo_test'] = $this->config->get('paymongo_test');
		}

		if (isset($this->request->post['paymongo_test_public_key'])) {
			$data['paymongo_test_public_key'] = $this->request->post['paymongo_test_public_key'];
		} else {
			$data['paymongo_test_public_key'] = $this->config->get('paymongo_test_public_key');
		}

		if (isset($this->request->post['paymongo_test_secret_key'])) {
			$data['paymongo_test_secret_key'] = $this->request->post['paymongo_test_secret_key'];
		} else {
			$data['paymongo_test_secret_key'] = $this->config->get('paymongo_test_secret_key');
		}

		if (isset($this->request->post['paymongo_live_public_key'])) {
			$data['paymongo_live_public_key'] = $this->request->post['paymongo_live_public_key'];
		} else {
			$data['paymongo_live_public_key'] = $this->config->get('paymongo_live_public_key');
		}

		if (isset($this->request->post['paymongo_live_secret_key'])) {
			$data['paymongo_live_secret_key'] = $this->request->post['paymongo_live_secret_key'];
		} else {
			$data['paymongo_live_secret_key'] = $this->config->get('paymongo_live_secret_key');
		}

		if (isset($this->request->post['paymongo_order_status_id'])) {
			$data['paymongo_order_status_id'] = $this->request->post['paymongo_order_status_id'];
		} else {
			$data['paymongo_order_status_id'] = $this->config->get('paymongo_order_status_id');
		}
		
		//webhook url
		$data['paymongo_webhook_url'] = $this->config->get('paymongo_webhook_url');
		$data['token'] = $this->request->get['token'];	
		//webhook url
		
		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['paymongo_status'])) {
			$data['paymongo_status'] = $this->request->post['paymongo_status'];
		} else {
			$data['paymongo_status'] = $this->config->get('paymongo_status');
		}

		if (isset($this->request->post['paymongo_sort_order'])) {
			$data['paymongo_sort_order'] = $this->request->post['paymongo_sort_order'];
		} else {
			$data['paymongo_sort_order'] = $this->config->get('paymongo_sort_order');
		}

		
		//Addtional Payment Paymongo
		if (isset($this->request->post['paymongo_gcash_status'])) {
			$data['paymongo_gcash_status'] = $this->request->post['paymongo_gcash_status'];
		} else {
			$data['paymongo_gcash_status'] = $this->config->get('paymongo_gcash_status');
		}

		if (isset($this->request->post['paymongo_gcash_sort_order'])) {
			$data['paymongo_gcash_sort_order'] = $this->request->post['paymongo_gcash_sort_order'];
		} else {
			$data['paymongo_gcash_sort_order'] = $this->config->get('paymongo_gcash_sort_order');
		}
		
		if (isset($this->request->post['paymongo_grab_pay_status'])) {
			$data['paymongo_grab_pay_status'] = $this->request->post['paymongo_grab_pay_status'];
		} else {
			$data['paymongo_grab_pay_status'] = $this->config->get('paymongo_grab_pay_status');
		}

		if (isset($this->request->post['paymongo_grab_pay_sort_order'])) {
			$data['paymongo_grab_pay_sort_order'] = $this->request->post['paymongo_grab_pay_sort_order'];
		} else {
			$data['paymongo_grab_pay_sort_order'] = $this->config->get('paymongo_grab_pay_sort_order');
		}
		
		if (isset($this->request->post['paymongo_paymaya_status'])) {
			$data['paymongo_paymaya_status'] = $this->request->post['paymongo_paymaya_status'];
		} else {
			$data['paymongo_paymaya_status'] = $this->config->get('paymongo_paymaya_status');
		}

		if (isset($this->request->post['paymongo_paymaya_sort_order'])) {
			$data['paymongo_paymaya_sort_order'] = $this->request->post['paymongo_paymaya_sort_order'];
		} else {
			$data['paymongo_paymaya_sort_order'] = $this->config->get('paymongo_paymaya_sort_order');
		}
		
		if (isset($this->request->post['paymongo_atome_status'])) {
			$data['paymongo_atome_status'] = $this->request->post['paymongo_atome_status'];
		} else {
			$data['paymongo_atome_status'] = $this->config->get('paymongo_atome_status');
		}

		if (isset($this->request->post['paymongo_atome_sort_order'])) {
			$data['paymongo_atome_sort_order'] = $this->request->post['paymongo_atome_sort_order'];
		} else {
			$data['paymongo_atome_sort_order'] = $this->config->get('paymongo_atome_sort_order');
		}
		
		if (isset($this->request->post['paymongo_billease_status'])) {
			$data['paymongo_billease_status'] = $this->request->post['paymongo_billease_status'];
		} else {
			$data['paymongo_billease_status'] = $this->config->get('paymongo_billease_status');
		}

		if (isset($this->request->post['paymongo_billease_sort_order'])) {
			$data['paymongo_billease_sort_order'] = $this->request->post['paymongo_billease_sort_order'];
		} else {
			$data['paymongo_billease_sort_order'] = $this->config->get('paymongo_billease_sort_order');
		}
		
		
				
		//Addtional Payment Paymongo
		
		
		if (isset($this->request->post['paymongo_entry_success_status_id'])) {
			$data['paymongo_entry_success_status_id'] = $this->request->post['paymongo_entry_success_status_id'];
		} else {
			$data['paymongo_entry_success_status_id'] = $this->config->get('paymongo_entry_success_status_id');
		}

		if (isset($this->request->post['paymongo_entry_failed_status_id'])) {
			$data['paymongo_entry_failed_status_id'] = $this->request->post['paymongo_entry_failed_status_id'];
		} else {
			$data['paymongo_entry_failed_status_id'] = $this->config->get('paymongo_entry_failed_status_id');
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/paymongo', $data));
	}

	public function install() {
		$this->load->model('extension/payment/paymongo');
		$this->model_extension_payment_paymongo->install();
		//Addtional Payment Paymongo install
		$this->load->model('extension/extension');
		$this->model_extension_extension->install('payment', 'paymongo_gcash');
		$this->model_extension_extension->install('payment', 'paymongo_grab_pay');
		$this->model_extension_extension->install('payment', 'paymongo_paymaya');
		$this->model_extension_extension->install('payment', 'paymongo_atome');
		$this->model_extension_extension->install('payment', 'paymongo_billease');
		//Addtional Payment Paymongo install
	}

	public function uninstall() {
		$this->load->model('extension/payment/paymongo');
		$this->model_extension_payment_paymongo->uninstall();
		//Addtional Payment Paymongo install
		$this->load->model('extension/extension');
		$this->model_extension_extension->uninstall('payment', 'paymongo_gcash');
		$this->model_extension_extension->uninstall('payment', 'paymongo_grab_pay');
		$this->model_extension_extension->uninstall('payment', 'paymongo_paymaya');
		$this->model_extension_extension->uninstall('payment', 'paymongo_atome');
		$this->model_extension_extension->uninstall('payment', 'paymongo_billease');
		//Addtional Payment Paymongo install
	}

	public function order() {

		if ($this->config->get('paymongo_status')) {

			$this->load->model('extension/payment/paymongo');

			$paymongo_order = $this->model_extension_payment_paymongo->getOrder($this->request->get['order_id']);

			if (!empty($paymongo_order)) {
				$this->load->language('extension/payment/paymongo');

				$paymongo_order['total_formatted'] = $this->currency->format($paymongo_order['total'], $paymongo_order['currency_code'], false);
				
				$data['paymongo_order'] = $paymongo_order;

				$data['text_payment_info'] = $this->language->get('text_payment_info');
				$data['text_order_ref'] = $this->language->get('text_order_ref');
				$data['text_order_total'] = $this->language->get('text_order_total');
				$data['text_total_released'] = $this->language->get('text_total_released');
				$data['text_release_status'] = $this->language->get('text_release_status');
				$data['text_void_status'] = $this->language->get('text_void_status');
				$data['text_refund_status'] = $this->language->get('text_refund_status');
				$data['text_transactions'] = $this->language->get('text_transactions');
				$data['text_yes'] = $this->language->get('text_yes');
				$data['text_no'] = $this->language->get('text_no');
				$data['text_column_amount'] = $this->language->get('text_column_amount');
				$data['text_column_type'] = $this->language->get('text_column_type');
				$data['text_column_date_added'] = $this->language->get('text_column_date_added');
				$data['button_release'] = $this->language->get('button_release');
				$data['button_refund'] = $this->language->get('button_refund');
				$data['button_void'] = $this->language->get('button_void');
				$data['text_confirm_void'] = $this->language->get('text_confirm_void');
				$data['text_confirm_release'] = $this->language->get('text_confirm_release');
				$data['text_confirm_refund'] = $this->language->get('text_confirm_refund');

				$data['order_id'] = $this->request->get['order_id'];
				$data['token'] = $this->request->get['token'];

				return $this->load->view('extension/payment/paymongo_order', $data);
			}
		}
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/paymongo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$data['entry_test_public_key'] = $this->language->get('entry_test_public_key');
		$data['entry_test_secret_key'] = $this->language->get('entry_test_secret_key');		
		$data['entry_live_public_key'] = $this->language->get('entry_live_public_key');
		$data['entry_live_secret_key'] = $this->language->get('entry_live_secret_key');

		if (!$this->request->post['paymongo_test_public_key']) {
			$this->error['error_test_public_key'] = $this->language->get('error_test_public_key');
		}

		if (!$this->request->post['paymongo_test_secret_key']) {
			$this->error['error_test_secret_key'] = $this->language->get('error_test_secret_key');
		}
		if (!$this->request->post['paymongo_live_public_key']) {
			$this->error['error_live_public_key'] = $this->language->get('error_live_public_key');
		}

		if (!$this->request->post['paymongo_live_secret_key']) {
			$this->error['error_live_secret_key'] = $this->language->get('error_live_secret_key');
		}

		return !$this->error;
	}
	
	public function generateWebhook()
	{
					$json = array();
					$this->load->language('extension/payment/paymongo');
					$this->load->model('setting/setting');
					
					$store_url=$this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
					
					$secret_key='';  
					if( $this->config->get('paymongo_test') == 'test' ){
						$secret_key = $this->config->get('paymongo_test_secret_key');
					} else if ( $this->config->get('paymongo_test') == 'live' ){
						$secret_key = $this->config->get('paymongo_live_secret_key');
					} 
					
					//attribute
					$attributes = array(
						'url' => $store_url.'index.php?route=extension/payment/paymongo_webhook',
						'events' => array("source.chargeable","payment.paid","payment.failed")		 
					);
					$payload = json_encode(
						array(
							'data' => array(
								'attributes' => $attributes,
							),
						)
					);
					//attribute
					
				$curl = curl_init();
				
				curl_setopt_array($curl, [
				  CURLOPT_URL => "https://api.paymongo.com/v1/webhooks",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => $payload,
				  CURLOPT_HTTPHEADER => [
					"accept: application/json",
					"Authorization: Basic ".base64_encode($secret_key.':'),
					"content-type: application/json"
				  ],
				]);
				
				$response = json_decode(curl_exec($curl));
				$err = curl_error($curl);
				
				curl_close($curl);
				
				if ($err) {
				   $json['error']=$this->language->get('error_curl'). $err;
				} else {
								$body = json_decode(json_encode($response),true);
								$erroretrun='';
								//check webhook exist
								$paymongo_webhook_url='';
								//check webhook exist
								if(isset($body['errors'])) {
										for ($i = 0; $i < count($body['errors']); $i++) {
											$erroretrun .=$body['errors'][$i]['detail'];
											//check webhook exist
											  if($body['errors'][$i]['code']=='resource_exists')
											{
												$paymongo_webhook_url=$store_url.'index.php?route=extension/payment/paymongo_webhook';
												$paymongo=array();
		
												$paymongo['paymongo_webhook_data']='';
		
												$paymongo['paymongo_webhook_url']=$paymongo_webhook_url;
		
												$this->model_setting_setting->editSetting('paymongo_webhook', $paymongo);
		
												$json['success']=$this->language->get('text_webhook_url_generated');
												
												
											}	
											//check webhook exist
										}
										
										//check webhook exist
										if($paymongo_webhook_url=='')
										{
											$json['error']=$erroretrun;
										}
										//check webhook exist
								}	
								else
								{
									
									if (array_key_exists('data', $body)
									&& array_key_exists('attributes', $body['data'])
									&& array_key_exists('status', $body['data']['attributes'])
									) {
										$paymongo_webhook_data=json_encode($response);
										$paymongo_webhook_url=$body['data']['attributes']['url'];
										
										
										$paymongo=array();
										$paymongo['paymongo_webhook_data']=$paymongo_webhook_data;
										$paymongo['paymongo_webhook_url']=$paymongo_webhook_url;
										$this->model_setting_setting->editSetting('paymongo_webhook', $paymongo);
										$json['success']=$this->language->get('text_webhook_url_generated');
									  
									  }
								}
				 	
				}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
				
	}
}
