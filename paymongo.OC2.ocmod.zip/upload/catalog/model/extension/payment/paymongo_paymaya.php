<?php



class ModelExtensionPaymentPaymongoPaymaya extends Model {



	public function getMethod($address, $total)

	{

		$status = true;



		$this->load->language('extension/payment/paymongo_paymaya');



		$method_data = array();



		if ($status) {

			$method_data = array(

				'code' => 'paymongo_paymaya',

				'title' => $this->language->get('text_title'),

				'terms' => '',

				'sort_order' => $this->config->get('paymongo_paymaya_sort_order')

			);

		}



		return $method_data;

	}

	public function updateOrderStatus($order_status_id, $order_id) {

		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '".$order_status_id."', date_modified = NOW() WHERE order_id = '" . (int)$order_id . "'");

	}
	
	public function addOrderHistory($order_id, $order_status_id,$notify,$message) {

		$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '".$order_status_id."', notify = '".$notify."', comment = '" . $this->db->escape($message) . "', date_added = NOW()");

	}
	

 
 	public function addOrder($order_info, $order_code) {

		$this->db->query("INSERT INTO `" . DB_PREFIX . "paymongo_order` SET `order_id` = '" . (int)$order_info['order_id'] . "', `order_code` = '" . $this->db->escape($order_code) . "', `date_added` = now(), `date_modified` = now(), `currency_code` = '" . $this->db->escape($order_info['currency_code']) . "', `total` = '" . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false) . "'");

		return $this->db->getLastId();

	}
	public function addTransaction($paymongo_order_id, $type, $order_info) {

		$this->db->query("INSERT INTO `" . DB_PREFIX . "paymongo_order_transaction` SET `paymongo_order_id` = '" . (int)$paymongo_order_id . "', `date_added` = now(), `type` = '" . $this->db->escape($type) . "', `amount` = '" . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false) . "'");

	}
	public function getKey( $APIkey = 'public' )

	{

		$key = '';



		if( $this->config->get('paymongo_test') == 'test' ){

			$key = $this->config->get('paymongo_test_' . $APIkey . '_key');

		} else if ( $this->config->get('paymongo_test') == 'live' ){

			$key = $this->config->get('paymongo_live_' . $APIkey . '_key');

		}



		return $key;

	}
	


	private function curlRrequest($url, $key, $order_data = null, $method =  'POST' ) { 

		$this->load->language('extension/payment/paymongo_paymaya');
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, 'https://api.paymongo.com/'.$url);
		$content_length = 0;
		if ($order_data) {
			$json = json_encode($order_data);
			$content_length = strlen($json);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		curl_setopt($curl, CURLOPT_TIMEOUT, 10);
		curl_setopt(
				$curl, CURLOPT_HTTPHEADER, array(
			"Authorization: Basic " . base64_encode( $key ),
			"Content-Type: application/json",
			"Content-Length: " . $content_length
				)
		);		

		$result = json_decode(curl_exec($curl));

		curl_close($curl);



		if(empty($result))

		{

			$result = new stdClass();

			$result->errors = [new stdClass()];

			$result->errors[0]->detail =  $this->language->get('error_paymongo_site');

		}



		return $result;

	}



	
	public function CreatePaymentMethod( $order_data )

	{

		return $this->curlRrequest( 'v1/payment_methods', $this->getKey( 'public' ), $order_data, 'POST' );

	}
	
	public function CreatePaymentIntent( $order_data )

	{

		return $this->curlRrequest( 'v1/payment_intents', $this->getKey( 'secret' ), $order_data, 'POST' );

	}

	public function AttachToPaymentIntent($paymentIntentId,$order_data )
	{
		return  $this->curlRrequest( 'v1/payment_intents/' . $paymentIntentId . '/attach', $this->getKey( 'public' ), $order_data, 'POST' );

	}

}

