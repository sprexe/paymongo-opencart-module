<?php

class ModelExtensionPaymentPaymongo extends Model {

	public function getMethod($address, $total)
	{
		$status = true;

		$this->load->language('extension/payment/paymongo');

		$method_data = array();

		if ($status) {
			$method_data = array(
				'code' => 'paymongo',
				'title' => $this->language->get('text_title'),
				'terms' => '',
				'sort_order' => $this->config->get('paymongo_sort_order')
			);
		}

		return $method_data;
	}

	public function addOrder($order_info, $order_code) {

		$this->db->query("INSERT INTO `" . DB_PREFIX . "paymongo_order` SET `order_id` = '" . (int)$order_info['order_id'] . "', `order_code` = '" . $this->db->escape($order_code) . "', `date_added` = now(), `date_modified` = now(), `currency_code` = '" . $this->db->escape($order_info['currency_code']) . "', `total` = '" . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false) . "'");

		return $this->db->getLastId();
	}

	public function getOrder($order_id) {
		$qry = $this->db->query("SELECT * FROM `" . DB_PREFIX . "paymongo_order` WHERE `order_id` = '" . (int)$order_id . "' LIMIT 1");

		if ($qry->num_rows) {
			$order = $qry->row;
			$order['transactions'] = $this->getTransactions($order['paymongo_order_id']);

			return $order;
		} else {
			return false;
		}
	}

	public function addTransaction($paymongo_order_id, $type, $order_info) {
		$this->db->query("INSERT INTO `" . DB_PREFIX . "paymongo_order_transaction` SET `paymongo_order_id` = '" . (int)$paymongo_order_id . "', `date_added` = now(), `type` = '" . $this->db->escape($type) . "', `amount` = '" . $this->currency->format($order_info['total'], $order_info['currency_code'], false, false) . "'");
	}

	public function getTransactions($paymongo_order_id) {
		$qry = $this->db->query("SELECT * FROM `" . DB_PREFIX . "paymongo_order_transaction` WHERE `paymongo_order_id` = '" . (int)$paymongo_order_id . "'");

		if ($qry->num_rows) {
			return $qry->rows;
		} else {
			return false;
		}
	} 

	public function getPaymongoOrder($paymongo_order_id) {
		$qry = $this->db->query("SELECT * FROM " . DB_PREFIX . "paymongo_order WHERE order_code = " . (int)$paymongo_order_id);
		return $qry->row;
	}
	
	public function recurringPayments() {
		/*
		 * Used by the checkout to state the module
		 * supports recurring profiles.
		 */
		return false;
	}

	/*****************new 3ds Payment******************/
 
	private function getKey( $APIkey = 'public' )
	{
		$key = '';

		if( $this->config->get('paymongo_test') == 'test' ){
			$key = $this->config->get('paymongo_test_' . $APIkey . '_key');
		} else if ( $this->config->get('paymongo_test') == 'live' ){
			$key = $this->config->get('paymongo_live_' . $APIkey . '_key');
		}

		return $key;
	}

	private function curlRrequest($url, $key, $order_data = null, $method =  'POST' ) { 
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, 'https://api.paymongo.com/'.$url);
		$content_length = 0;
		if ($order_data) {
			$json = json_encode($order_data);
			$content_length = strlen($json);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		curl_setopt($curl, CURLOPT_TIMEOUT, 10);
		curl_setopt(
				$curl, CURLOPT_HTTPHEADER, array(
			"Authorization: Basic " . base64_encode( $key ),
			"Content-Type: application/json",
			"Content-Length: " . $content_length
				)
		);
		$result = json_decode(curl_exec($curl));
		curl_close($curl);

		if(empty($result))
		{
			$result = new stdClass();
			$result->errors = [new stdClass()];
			$result->errors[0]->detail = '<h3>Не удается получить доступ к сайту</h3><p>Превышено время ожидания ответа от сайта <b>paymongo.com</b>.</p>';
		}

		return $result;
	}

	public function CreatePaymentIntent( $order_data )
	{
		return $this->curlRrequest( 'v1/payment_intents', $this->getKey( 'secret' ), $order_data, 'POST' );
	}

	public function AttachToPaymentIntent( $order_data )
	{
		// Get the payment intent id from the client key
		$paymentIntentId = explode('_client',$order_data['data']['attributes']['client_key'])[0];
		return  $this->curlRrequest( 'v1/payment_intents/' . $paymentIntentId . '/attach', $this->getKey( 'public' ), $order_data, 'POST' );
	}

	public function statusPaymentIntent( $client_key )
	{
		// Get the payment intent id from the client key
		$paymentIntentId = explode('_client',$client_key)[0];
		$result = $this->curlRrequest( 'v1/payment_intents/' . $paymentIntentId, $this->getKey( 'public' ),['client_key'=>$client_key],'GET' );

		if($result->data->attributes->last_payment_error)
		{
			$result->errors = [new stdClass()];
			$result->errors[0]->detail = $result->data->attributes->last_payment_error->failed_message;
		}
		
		return $result;
	}

	public function CreatePaymentMethod( $order_data )
	{
		return $this->curlRrequest( 'v1/payment_methods', $this->getKey( 'public' ), $order_data, 'POST' );
	}


}
