<?php

// Text
$_['text_title']			 = 'Credit Card / Debit Card (paymongo)';
$_['text_credit_card']		 = 'Card Details';
$_['text_card_type']		 = 'Card Type: ';
$_['text_card_name']		 = 'Card Name: ';
$_['text_card_digits']		 = 'Last Digits: ';
$_['text_card_expiry']		 = 'Expiry: ';
$_['text_trial']			 = '%s every %s %s for %s payments then ';
$_['text_recurring']		 = '%s every %s %s';
$_['text_length']			 = ' for %s payments';
$_['text_confirm_delete']	 = 'Are you sure you wish to delete this card';
$_['text_card_success']		 = 'Card has been successfully removed';
$_['text_card_error']		 = 'There are an error removing your card. Please contact the shop administrator for help.';

// Entry
$_['entry_card']			 = 'New or Existing Card: ';
$_['entry_card_existing']	 = 'Existing';
$_['entry_card_new']		 = 'New';
$_['entry_card_save']		 = 'Remember Card Details';
$_['entry_cc_cvc']			 = 'Card Verification Code (CVC)';
$_['entry_cc_choice']		 = 'Choose an Existing Card';

$_['entry_cc_type']				= 'Card Type';
$_['entry_cc_number']			= 'Card Number';
$_['entry_cc_expire_date']		= 'Card Expiry Date';
$_['entry_cc_cvv2']				= 'Card Security Code (CVV2)';

// Button
$_['button_delete_card']	 = 'Delete Card';

// Error
$_['error_process_order']	 = 'There are an error processing your order. Please contact the shop administrator for help.';
