
<?php
class ControllerExtensionPaymentPaymongo extends Controller {
	public function index()
	{
		$this->load->language('extension/payment/paymongo');
		$data['text_credit_card'] = $this->language->get('text_credit_card');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['text_card_type'] = $this->language->get('text_card_type');
		$data['text_card_name'] = $this->language->get('text_card_name');
		$data['text_card_digits'] = $this->language->get('text_card_digits');
		$data['text_card_expiry'] = $this->language->get('text_card_expiry');
		$data['text_confirm_delete'] = $this->language->get('text_confirm_delete');

		$data['entry_card'] = $this->language->get('entry_card');
		$data['entry_card_existing'] = $this->language->get('entry_card_existing');
		$data['entry_card_new'] = $this->language->get('entry_card_new');
		$data['entry_card_save'] = $this->language->get('entry_card_save');
		$data['entry_cc_cvc'] = $this->language->get('entry_cc_cvc');
		$data['entry_cc_choice'] = $this->language->get('entry_cc_choice');
		$data['entry_cc_type'] = $this->language->get('entry_cc_type');		
		$data['entry_cc_number'] = $this->language->get('entry_cc_number');
		$data['entry_cc_expire_date'] = $this->language->get('entry_cc_expire_date');
		$data['entry_cc_cvv2'] = $this->language->get('entry_cc_cvv2');
		$data['button_delete_card'] = $this->language->get('button_delete_card');
		$data['button_confirm'] = $this->language->get('button_confirm');
		
		$data['SFWidget_css'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/css/SFWModal.min.css?1.0.0';
		$data['SFWidget_script'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/js/SFWModal.js?1.0.0';

		$data['form_submit'] = $this->url->link('extension/payment/paymongo/paymentSend', '', true);

		$data['months'] = array();

		for ($i = 1; $i <= 12; $i++) 
		{
			$data['months'][] = array(
				'text' => strftime('%B', mktime(0, 0, 0, $i, 1, 2000)),
				'value' => sprintf('%d', $i)
			);
		}

		$today = getdate();

		$data['year_expire'] = array();

		for ($i = $today['year']; $i < $today['year'] + 11; $i++) 
		{
			$data['year_expire'][] = array(
				'text' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i)),
				'value' => strftime('%Y', mktime(0, 0, 0, 1, 1, $i))
			);
		}

		return $this->load->view('extension/payment/paymongo', $data);
	}

	public function paymentSend()
	{
		
		$this->load->language('extension/payment/paymongo');
		$this->load->model('checkout/order');
		$this->load->model('localisation/country');
		$this->load->model('extension/payment/paymongo');

		//if order undefined
		$errors = NULL;
		if(!isset($this->session->data['order_id']))
		{
			$errors['error']  = $this->language->get('error_process_order');
			$this->printJSON($errors);
		}
		
		//get current order
		$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
		
		//Сreating a data to send PaymentIntent
		$paymentIntendData = [
			"data" => [
				"attributes" => [
					"amount" => round($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false)*100), 
					"payment_method_allowed" => [
						"card"
					], 
					"payment_method_options" => [
						"card" => [
							"request_three_d_secure" => "any" 
						] 
					], 
					"currency" => "PHP",
					"description" => $order_info['store_name'] .' - Order ID:- '.$order_info['order_id']. '  - ' . date('Y-m-d H:i:s'),
					"statement_descriptor"=> $order_info['store_name'].' '.$order_info['order_id']
				] 
			] 
		]; 

		//Update PaymentIntent data using secret API key
		$paymentIntendData = $this->model_extension_payment_paymongo->CreatePaymentIntent($paymentIntendData);

		// check any errors in response datas
		if( isset($paymentIntendData->errors))
		{
			$errors['error'] = $paymentIntendData->errors[0]->detail;
			$this->printJSON($errors);
		}

		//Сreating a data to send PaymentMethod
		$PaymentMethodData = [
		   "data" => [
				"attributes" => [
					"details" => [
						"card_number" => $this->request->post['cc_number'], 
						"exp_month" => intval($this->request->post['cc_expire_date_month']), 
						"exp_year" => intval(substr($this->request->post['cc_expire_date_year'],2)), 
						"cvc" => $this->request->post['cc_cvv2'], 
					], 
					"billing" => [
						"address" => [
							"line1" => $order_info['payment_address_1'], 
							"line2" => $order_info['payment_address_2'], 
							"city" => $order_info['payment_city'], 
							"state" => $order_info['payment_zone'], 
							"postal_code" => $order_info['payment_postcode'], 
							"country" => $this->model_localisation_country->getCountry($order_info['payment_country_id'])['iso_code_2'] 
						], 
						"name" => $order_info['firstname'] . ' ' . $order_info['lastname'], 
						"email" => substr($order_info['email'], 0, 255), 
						"phone" => substr($order_info['telephone'], 0, 20) 
					], 
					"type" => "card" 
				] 
			] 
		]; 
		
		//Update PaymentIntent data using secret API key
		$PaymentMethodData = $this->model_extension_payment_paymongo->CreatePaymentMethod($PaymentMethodData);
		
		// check any errors in response datas
		if(isset($PaymentMethodData->errors))
		{
			$errors['error'] = $PaymentMethodData->errors[0]->detail;
			$this->printJSON($errors);
		}

		//Сreating a data to send Attach To PaymentIntent
		$AttachToPaymentIntentData = [
			"data" => [
				"attributes" => [
					"payment_method" => $PaymentMethodData->data->id, 
					"client_key" => $paymentIntendData->data->attributes->client_key
				]
			]
		];

		//Update Attach To PaymentIntent data using client key
		$AttachToPaymentIntentData = $this->model_extension_payment_paymongo->AttachToPaymentIntent($AttachToPaymentIntentData);
		
		// check any errors in response datas
		if(isset($AttachToPaymentIntentData->errors))
		{
			$errors['error'] = $AttachToPaymentIntentData->errors[0]->detail;
			$this->printJSON($errors);
		}
		else
		{
			if($AttachToPaymentIntentData->data->attributes->status == "succeeded")
			{
				$AttachToPaymentIntentData->data->success_link = $this->url->link('checkout/success', '', true);
				$this->orderSuccess($AttachToPaymentIntentData->data->id,$order_info);
			}

			$this->printJSON($AttachToPaymentIntentData);
		}	
	}
	public function paymentStatus()
	{

		$this->load->model('extension/payment/paymongo');
		
		//Сreating a data status of payment
		$clientKey = $this->request->post['client_key'];
		
		//get PaymentIntent status by client key
		$PaymentStatusData = $this->model_extension_payment_paymongo->statusPaymentIntent($clientKey);

		$errors = NULL;
		
		// check any errors in response datas
		if(isset($PaymentStatusData->errors))
		{
			
			$errors['error'] = $PaymentStatusData->errors[0]->detail;
			$this->printJSON($errors);
		}
		else
		{
			if($PaymentStatusData->data->attributes->status == "succeeded")
			{
				$this->load->model('checkout/order');
				$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
				$PaymentStatusData->data->success_link = $this->url->link('checkout/success', '', true);

				$this->orderSuccess($PaymentStatusData->data->id,$order_info);
			}

			$this->printJSON($PaymentStatusData);
		}	
	}

	public function orderSuccess($paymentId,$order_info)
	{
			$this->model_extension_payment_paymongo->addOrder($order_info, $paymentId );

			$message = 'Payment ID:- '.$paymentId; 
			
			$paymongo_order_info = $this->model_extension_payment_paymongo->getOrder($order_info['order_id']);

			$this->model_extension_payment_paymongo->addTransaction($paymongo_order_info['paymongo_order_id'], 'payment', $order_info);
			
			$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('paymongo_order_status_id'), $message, false);

	}

	private function printJSON($json)
	{
		$this->response->addHeader('Content-Type: application/json');
		exit(json_encode($json));
	}
}
