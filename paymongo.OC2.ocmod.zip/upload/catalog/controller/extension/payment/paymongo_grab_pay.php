
<?php
class ControllerExtensionPaymentPaymongoGrabPay extends Controller {
	public function index()
	{
		$this->load->language('extension/payment/paymongo_grab_pay');
		
		$data['button_continue'] = $this->language->get('button_continue');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['SFWidget_css'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/css/SFWModal.min.css?1.0.0';

		$data['SFWidget_script'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/js/SFWModal.js?1.0.0';

		return $this->load->view('extension/payment/paymongo_grab_pay', $data);
		
		}

	public function paymentSend()
	{			
				$json = array();
				if ((!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) || (!$this->cart->hasStock() && !$this->config->get('config_stock_checkout'))) {
					$json['redirect']=$this->url->link('checkout/cart', '', true);
					$this->printJSON($json);
				}
				
				$this->load->language('extension/payment/paymongo_grab_pay');
				$this->load->model('checkout/order');
				$this->load->model('localisation/country');
				$this->load->model('extension/payment/paymongo_grab_pay');
				
				//if order undefined
				if(!isset($this->session->data['order_id']))
				{
					$json['error']  = $this->language->get('error_process_order');
					$this->printJSON($json);
				}
				
				//get current order
				$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
				 
				//Creating a data to send PaymentIntent
				$payloadData = [
							"data" => [
								"attributes" => [
										'type' => "grab_pay",
										'amount' =>  round($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false)*100),
										'currency' => 'PHP', // hard-coded for now
										'description' => $order_info['store_name'] .' - Order ID:- '.$order_info['order_id']. '  - ' . date('Y-m-d H:i:s'),
										'redirect' => array(
											'success' => $this->url->link('extension/payment/paymongo_grab_pay/paymentStatus&order=' . $order_info['order_id'] . '&status=success&agent=cynder_opencart&version=1.10.0', '', true),
											'failed' => $this->url->link('checkout/checkout', '', true)
										),
										"billing" => [
													"address" => [
														"line1" => $order_info['payment_address_1'], 
														"line2" => $order_info['payment_address_2'], 
														"city" => $order_info['payment_city'], 
														"state" => $order_info['payment_zone'], 
														"postal_code" => $order_info['payment_postcode'], 
														"country" => $this->model_localisation_country->getCountry($order_info['payment_country_id'])['iso_code_2'] 
													],
													"name" => $order_info['firstname'] . ' ' . $order_info['lastname'], 
													"email" => substr($order_info['email'], 0, 255), 
													"phone" => substr($order_info['telephone'], 0, 20)
											]		 
								] 
							] 
						];
					//Send Payment data using secret API key
					$PaymentSourcesData = $this->model_extension_payment_paymongo_grab_pay->PaymentSourcesData($payloadData);
					
					// check any errors in response datas
					if(isset($PaymentSourcesData->errors))
					{
						$json['error'] = $PaymentSourcesData->errors[0]->detail;
						if(@$PaymentSourcesData->errors[0]->code=='parameter_below_minimum')
						{
							$json['error']=$this->language->get('error_below_minimum');
						}
						$this->printJSON($json);
					}
					
					if($PaymentSourcesData->data->attributes->status == "pending")
					{
									$message = 'source_id:- '.$PaymentSourcesData->data->id; 
									$this->model_extension_payment_paymongo_grab_pay->updateOrderStatus(0,$order_info['order_id']);
									$this->model_extension_payment_paymongo_grab_pay->addOrderHistory($order_info['order_id'],15,0,$message);
									$json['redirect']=$PaymentSourcesData->data->attributes->redirect->checkout_url;
									$this->printJSON($json);
					}
					
					
	}
	public function paymentStatus()
	{
			 $this->load->model('checkout/order');
			 $orderId = $_GET['order'];
 			 $status = $_GET['status'];
			 $order_info = $this->model_checkout_order->getOrder($orderId);
			 if ($status === 'success') {
			 	$this->model_checkout_order->addOrderHistory($orderId, $this->config->get('paymongo_order_status_id'));
				$this->redirectPage($this->url->link('checkout/success', '', true));
			 } else if ($status === 'failed') {
			 	$this->session->data['error']=$this->language->get('error_paymentstatus');
				$this->redirectPage($this->url->link('checkout/checkout', '', true));
			 }
	}
	
	private function printJSON($json)
	{
		$this->response->addHeader('Content-Type: application/json');
		exit(json_encode($json));
	}
	
	private function redirectPage($url)
	{ 
	?>
	<script language="javascript">window.location.href = "<?php echo $url;?>";</script>
	<?php 
	}
}
