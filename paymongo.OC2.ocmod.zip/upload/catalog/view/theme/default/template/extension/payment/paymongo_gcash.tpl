<div class="buttons">
  <div class="pull-right">
    <a href="javscript:void(0);" onClick="paymentSend();" class="btn btn-primary" id="button-confirm" data-loading-text="<?php echo $text_loading;?>"><?php echo $button_continue;?></a>
  </div>
</div>
<link type="text/css" rel="stylesheet" href="<?php echo $SFWidget_css ?>" media="screen,projection" />
<script src="<?php echo $SFWidget_script ?>"></script>
<script type="text/javascript"><!--
$('#button-confirm').on('click', function() {
	$('#button-confirm').button('loading');
});
function paymentSend()
{

	 $.ajax({
        url: 'index.php?route=extension/payment/paymongo_gcash/paymentSend/',
        type: 'post',
		dataType: 'json',
        cache: false,
		beforeSend: function() 
		{
			$('#button-confirm').button('loading');
        },
		complete: function()
		{
			$('#button-confirm').button('reset');
		},
		success: function(json) 
		{
			if (json['redirect'])
			{
				location = json['redirect'];
			}
			if(json['error'])
			{
				SFWModal({
				modalout:'top',
				modalsize:"xs",
				background:true,
				content:json['error']
				});

				return;

			}
		}
	});
}
//--></script>