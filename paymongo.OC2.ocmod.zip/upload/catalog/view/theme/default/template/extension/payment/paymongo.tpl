<form id="payment-new-form" action="<?php echo $form_submit; ?>" method="post" class="form-horizontal">
	<fieldset id="payment">
		<legend><?php echo $text_credit_card; ?></legend>
		<div class="form-group required">
		  <label class="col-sm-2 control-label" for="input-cc-number"><?php echo $entry_cc_number; ?></label>
		  <div class="col-sm-10">
			<input type="text" required="required" name="cc_number" value="" placeholder="<?php echo $entry_cc_number; ?>" id="input-cc-number" class="form-control" />
		  </div>
		</div>
		<div class="form-group required">
		  <label class="col-sm-2 control-label" for="input-cc-expire-date"><?php echo $entry_cc_expire_date; ?></label>
		  <div class="col-sm-3">
			<select name="cc_expire_date_month" id="input-cc-expire-date" class="form-control">
			  <?php foreach ($months as $month) { ?>
				  <option value="<?php echo $month['value']; ?>" ><?php echo $month['text']; ?></option>
			  <?php } ?>
			</select>
		  </div>
		  <div class="col-sm-3">
			<select name="cc_expire_date_year" class="form-control">
			  <?php foreach ($year_expire as $year) { ?>
				  <option value="<?php echo $year['value']; ?>" ><?php echo $year['text']; ?></option>
			  <?php } ?>
			</select>
		  </div>
		</div>
		<div class="form-group required">
		  <label class="col-sm-2 control-label" for="input-cc-cvv2"><?php echo $entry_cc_cvv2; ?></label>
		  <div class="col-sm-10">
			<input  required="required" type="text" name="cc_cvv2" value="" placeholder="<?php echo $entry_cc_cvv2; ?>" id="input-cc-cvv2" class="form-control" />
		  </div>
		</div>
	</fieldset>
	<div class="buttons">
		<div class="buttons">
			<img class="col-sm-2" src="catalog/view/theme/default/image/sectigo.jpg" width="18%" height="18%">
			<img class="col-sm-2" src="catalog/view/theme/default/image/ssl.jpg" width="18%" height="18%">
			<div class="col-sm-8 text-right"><input type="submit" value="<?php echo $button_confirm; ?>" id="button-confirm" data-loading-text="<?php echo $text_loading; ?>" class="btn btn-primary" /></div>
		</div>
	</div>		
</form>
<link type="text/css" rel="stylesheet" href="<?php echo $SFWidget_css ?>" media="screen,projection" />
<script src="<?php echo $SFWidget_script ?>"></script>
<script type="text/javascript">
var clientKey;
var modalAwaiting;
const paymongo = function(intent)
{
	var data = 
	{
		paymentSend:$('#payment-new-form').serialize(),
		paymentStatus:{client_key:clientKey}
	}

    $.ajax({
        url: 'index.php?route=extension/payment/paymongo/' + intent,
        type: 'post',
        data: data[intent],
		dataType: 'json',
        cache: false,
		beforeSend: function() 
		{
			$('#button-confirm').button('loading');
        },
		complete: function()
		{
			$('#button-confirm').button('reset');
		},
		success: function(json) 
		{
			if (json['error'])
			{
				SFWModal({
				modalout:'top',
				modalsize:"xs",
				background:true,
				content:json['error']
				});

				return;
			}

			if(json.data && json.data.attributes)
			{
				var paymentIntent = json.data;
				var paymentIntentStatus = paymentIntent.attributes.status;

				clientKey = paymentIntent.attributes.client_key
				
				if (paymentIntentStatus === 'awaiting_next_action')
				{
					var $iframe = $('<iframe src = "' + paymentIntent.attributes.next_action.redirect.url + '" style="width:100%;height:80vh;border:0" ></iframe>');
					modalAwaiting = SFWModal({
					modalsize:"lg",
					background: true,
					content:$iframe
					});
				} 
				else if (paymentIntentStatus === 'succeeded')
				{
					location = paymentIntent['success_link'];
				}
				else if (paymentIntentStatus === 'processing')
				{
					setTimeout(function()
					{
						paymongo('paymentStatus');

					},2000);
				}
			}
		}
	})
}

$('#payment-new-form').bind('submit', function() 
{
	paymongo('paymentSend');

	return false;

});

window.addEventListener(
  'message',
  function(ev) 
  {
	  if (ev.data === '3DS-authentication-complete')
	  {
		  paymongo('paymentStatus');
		  modalAwaiting.close();
	  }
  },
  false
);

</script>