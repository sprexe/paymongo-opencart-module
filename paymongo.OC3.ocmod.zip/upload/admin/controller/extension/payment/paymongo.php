<?php
class ControllerExtensionPaymentPaymongo extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/payment/paymongo');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$payment_paymongo=array();
			$payment_paymongo['payment_paymongo_test_public_key']=$this->request->post['payment_paymongo_test_public_key'];
			$payment_paymongo['payment_paymongo_test_secret_key']=$this->request->post['payment_paymongo_test_secret_key'];
			$payment_paymongo['payment_paymongo_live_public_key']=$this->request->post['payment_paymongo_live_public_key'];
			$payment_paymongo['payment_paymongo_live_secret_key']=$this->request->post['payment_paymongo_live_secret_key'];
			$payment_paymongo['payment_paymongo_test']=$this->request->post['payment_paymongo_test'];
			$payment_paymongo['payment_paymongo_order_status_id']=$this->request->post['payment_paymongo_order_status_id'];
			$payment_paymongo['payment_paymongo_status']=$this->request->post['payment_paymongo_status'];
			$payment_paymongo['payment_paymongo_sort_order']=$this->request->post['payment_paymongo_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo', $payment_paymongo);
			
			//Addtional Payment Paymongo
			$payment_paymongo_gcash=array();
			$payment_paymongo_gcash['payment_paymongo_gcash_status']=$this->request->post['payment_paymongo_gcash_status'];
			$payment_paymongo_gcash['payment_paymongo_gcash_sort_order']=$this->request->post['payment_paymongo_gcash_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo_gcash', $payment_paymongo_gcash);
			
			$payment_paymongo_grab_pay=array();
			$payment_paymongo_grab_pay['payment_paymongo_grab_pay_status']=$this->request->post['payment_paymongo_grab_pay_status'];
			$payment_paymongo_grab_pay['payment_paymongo_grab_pay_sort_order']=$this->request->post['payment_paymongo_grab_pay_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo_grab_pay', $payment_paymongo_grab_pay);
			
			$payment_paymongo_paymaya=array();
			$payment_paymongo_paymaya['payment_paymongo_paymaya_status']=$this->request->post['payment_paymongo_paymaya_status'];
			$payment_paymongo_paymaya['payment_paymongo_paymaya_sort_order']=$this->request->post['payment_paymongo_paymaya_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo_paymaya', $payment_paymongo_paymaya);
			
			$payment_paymongo_atome=array();
			$payment_paymongo_atome['payment_paymongo_atome_status']=$this->request->post['payment_paymongo_atome_status'];
			$payment_paymongo_atome['payment_paymongo_atome_sort_order']=$this->request->post['payment_paymongo_atome_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo_atome', $payment_paymongo_atome);
			
			$payment_paymongo_billease=array();
			$payment_paymongo_billease['payment_paymongo_billease_status']=$this->request->post['payment_paymongo_billease_status'];
			$payment_paymongo_billease['payment_paymongo_billease_sort_order']=$this->request->post['payment_paymongo_billease_sort_order'];
			$this->model_setting_setting->editSetting('payment_paymongo_billease', $payment_paymongo_billease);
			//Addtional Payment Paymongo
			
			$this->session->data['success'] = $this->language->get('text_success');

			$this->response->redirect($this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true));
		}

		if (isset($this->error['error_test_public_key'])) {
			$data['error_test_public_key'] = $this->error['error_test_public_key'];
		} else {
			$data['error_test_public_key'] = '';
		}

		if (isset($this->error['error_test_secret_key'])) {
			$data['error_test_secret_key'] = $this->error['error_test_secret_key'];
		} else {
			$data['error_test_secret_key'] = '';
		}
		
		if (isset($this->error['error_live_public_key'])) {
			$data['error_live_public_key'] = $this->error['error_live_public_key'];
		} else {
			$data['error_live_public_key'] = '';
		}

		if (isset($this->error['error_live_secret_key'])) {
			$data['error_live_secret_key'] = $this->error['error_live_secret_key'];
		} else {
			$data['error_live_secret_key'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_extension'),
			'href' => $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/payment/paymongo', 'user_token=' . $this->session->data['user_token'], true)
		);

		$data['action'] = $this->url->link('extension/payment/paymongo', 'user_token=' . $this->session->data['user_token'], true);

		$data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=payment', true);
		
		if (isset($this->request->post['payment_paymongo_test'])) {
			$data['payment_paymongo_test'] = $this->request->post['payment_paymongo_test'];
		} else {
			$data['payment_paymongo_test'] = $this->config->get('payment_paymongo_test');
		}

		if (isset($this->request->post['payment_paymongo_test_public_key'])) {
			$data['payment_paymongo_test_public_key'] = $this->request->post['payment_paymongo_test_public_key'];
		} else {
			$data['payment_paymongo_test_public_key'] = $this->config->get('payment_paymongo_test_public_key');
		}

		if (isset($this->request->post['payment_paymongo_test_secret_key'])) {
			$data['payment_paymongo_test_secret_key'] = $this->request->post['payment_paymongo_test_secret_key'];
		} else {
			$data['payment_paymongo_test_secret_key'] = $this->config->get('payment_paymongo_test_secret_key');
		}

		if (isset($this->request->post['payment_paymongo_live_public_key'])) {
			$data['payment_paymongo_live_public_key'] = $this->request->post['payment_paymongo_live_public_key'];
		} else {
			$data['payment_paymongo_live_public_key'] = $this->config->get('payment_paymongo_live_public_key');
		}

		if (isset($this->request->post['payment_paymongo_live_secret_key'])) {
			$data['payment_paymongo_live_secret_key'] = $this->request->post['payment_paymongo_live_secret_key'];
		} else {
			$data['payment_paymongo_live_secret_key'] = $this->config->get('payment_paymongo_live_secret_key');
		}

		if (isset($this->request->post['payment_paymongo_order_status_id'])) {
			$data['payment_paymongo_order_status_id'] = $this->request->post['payment_paymongo_order_status_id'];
		} else {
			$data['payment_paymongo_order_status_id'] = $this->config->get('payment_paymongo_order_status_id');
		}
		
		//webhook url
		$data['payment_paymongo_webhook_url'] = $this->config->get('payment_paymongo_webhook_url');
		$data['user_token'] = $this->request->get['user_token'];	
		//webhook url

		$this->load->model('localisation/order_status');

		$data['order_statuses'] = $this->model_localisation_order_status->getOrderStatuses();

		if (isset($this->request->post['payment_paymongo_status'])) {
			$data['payment_paymongo_status'] = $this->request->post['payment_paymongo_status'];
		} else {
			$data['payment_paymongo_status'] = $this->config->get('payment_paymongo_status');
		}

		if (isset($this->request->post['payment_paymongo_sort_order'])) {
			$data['payment_paymongo_sort_order'] = $this->request->post['payment_paymongo_sort_order'];
		} else {
			$data['payment_paymongo_sort_order'] = $this->config->get('payment_paymongo_sort_order');
		}
		
		//Addtional Payment Paymongo
		if (isset($this->request->post['payment_paymongo_gcash_status'])) {
			$data['payment_paymongo_gcash_status'] = $this->request->post['payment_paymongo_gcash_status'];
		} else {
			$data['payment_paymongo_gcash_status'] = $this->config->get('payment_paymongo_gcash_status');
		}

		if (isset($this->request->post['payment_paymongo_gcash_sort_order'])) {
			$data['payment_paymongo_gcash_sort_order'] = $this->request->post['payment_paymongo_gcash_sort_order'];
		} else {
			$data['payment_paymongo_gcash_sort_order'] = $this->config->get('payment_paymongo_gcash_sort_order');
		}
		
		if (isset($this->request->post['payment_paymongo_grab_pay_status'])) {
			$data['payment_paymongo_grab_pay_status'] = $this->request->post['payment_paymongo_grab_pay_status'];
		} else {
			$data['payment_paymongo_grab_pay_status'] = $this->config->get('payment_paymongo_grab_pay_status');
		}

		if (isset($this->request->post['payment_paymongo_grab_pay_sort_order'])) {
			$data['payment_paymongo_grab_pay_sort_order'] = $this->request->post['payment_paymongo_grab_pay_sort_order'];
		} else {
			$data['payment_paymongo_grab_pay_sort_order'] = $this->config->get('payment_paymongo_grab_pay_sort_order');
		}
		
		if (isset($this->request->post['payment_paymongo_paymaya_status'])) {
			$data['payment_paymongo_paymaya_status'] = $this->request->post['payment_paymongo_paymaya_status'];
		} else {
			$data['payment_paymongo_paymaya_status'] = $this->config->get('payment_paymongo_paymaya_status');
		}

		if (isset($this->request->post['payment_paymongo_paymaya_sort_order'])) {
			$data['payment_paymongo_paymaya_sort_order'] = $this->request->post['payment_paymongo_paymaya_sort_order'];
		} else {
			$data['payment_paymongo_paymaya_sort_order'] = $this->config->get('payment_paymongo_paymaya_sort_order');
		}
		
		if (isset($this->request->post['payment_paymongo_atome_status'])) {
			$data['payment_paymongo_atome_status'] = $this->request->post['payment_paymongo_atome_status'];
		} else {
			$data['payment_paymongo_atome_status'] = $this->config->get('payment_paymongo_atome_status');
		}

		if (isset($this->request->post['payment_paymongo_atome_sort_order'])) {
			$data['payment_paymongo_atome_sort_order'] = $this->request->post['payment_paymongo_atome_sort_order'];
		} else {
			$data['payment_paymongo_atome_sort_order'] = $this->config->get('payment_paymongo_atome_sort_order');
		}
		
		if (isset($this->request->post['payment_paymongo_billease_status'])) {
			$data['payment_paymongo_billease_status'] = $this->request->post['payment_paymongo_billease_status'];
		} else {
			$data['payment_paymongo_billease_status'] = $this->config->get('payment_paymongo_billease_status');
		}

		if (isset($this->request->post['payment_paymongo_billease_sort_order'])) {
			$data['payment_paymongo_billease_sort_order'] = $this->request->post['payment_paymongo_billease_sort_order'];
		} else {
			$data['payment_paymongo_billease_sort_order'] = $this->config->get('payment_paymongo_billease_sort_order');
		}
		
		
				
		//Addtional Payment Paymongo
		

		if (isset($this->request->post['payment_paymongo_entry_success_status_id'])) {
			$data['payment_paymongo_entry_success_status_id'] = $this->request->post['payment_paymongo_entry_success_status_id'];
		} else {
			$data['payment_paymongo_entry_success_status_id'] = $this->config->get('payment_paymongo_entry_success_status_id');
		}

		if (isset($this->request->post['payment_paymongo_entry_failed_status_id'])) {
			$data['payment_paymongo_entry_failed_status_id'] = $this->request->post['payment_paymongo_entry_failed_status_id'];
		} else {
			$data['payment_paymongo_entry_failed_status_id'] = $this->config->get('payment_paymongo_entry_failed_status_id');
		}
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/payment/paymongo', $data));
	}

	public function install() {
		$this->load->model('extension/payment/paymongo');
		$this->model_extension_payment_paymongo->install();
		//Addtional Payment Paymongo install
		$this->load->model('setting/extension');
		$this->model_setting_extension->install('payment', 'paymongo_gcash');
		$this->model_setting_extension->install('payment', 'paymongo_grab_pay');
		$this->model_setting_extension->install('payment', 'paymongo_paymaya');
		$this->model_setting_extension->install('payment', 'paymongo_atome');
		$this->model_setting_extension->install('payment', 'paymongo_billease');
		//Addtional Payment Paymongo install
		
	}

	public function uninstall() {
		$this->load->model('extension/payment/paymongo');
		$this->model_extension_payment_paymongo->uninstall();
		//Addtional Payment Paymongo install
		$this->load->model('setting/extension');
		$this->model_setting_extension->uninstall('payment', 'paymongo_gcash');
		$this->model_setting_extension->uninstall('payment', 'paymongo_grab_pay');
		$this->model_setting_extension->uninstall('payment', 'paymongo_paymaya');
		$this->model_setting_extension->uninstall('payment', 'paymongo_atome');
		$this->model_setting_extension->uninstall('payment', 'paymongo_billease');
		//Addtional Payment Paymongo install
		
	}

	public function order() {
		if ($this->config->get('payment_paymongo_status')) {

			$this->load->model('extension/payment/paymongo');

			$paymongo_order = $this->model_extension_payment_paymongo->getOrder($this->request->get['order_id']);
			if (!empty($paymongo_order)) {
				$this->load->language('extension/payment/paymongo');

				$paymongo_order['total_formatted'] = $this->currency->format($paymongo_order['total'], $paymongo_order['currency_code'], false);
				
				$data['paymongo_order'] = $paymongo_order;

				$data['text_payment_info'] = $this->language->get('text_payment_info');
				$data['text_order_ref'] = $this->language->get('text_order_ref');
				$data['text_order_total'] = $this->language->get('text_order_total');
				$data['text_total_released'] = $this->language->get('text_total_released');
				$data['text_release_status'] = $this->language->get('text_release_status');
				$data['text_void_status'] = $this->language->get('text_void_status');
				$data['text_refund_status'] = $this->language->get('text_refund_status');
				$data['text_transactions'] = $this->language->get('text_transactions');
				$data['text_yes'] = $this->language->get('text_yes');
				$data['text_no'] = $this->language->get('text_no');
				$data['text_column_amount'] = $this->language->get('text_column_amount');
				$data['text_column_type'] = $this->language->get('text_column_type');
				$data['text_column_date_added'] = $this->language->get('text_column_date_added');
				$data['button_release'] = $this->language->get('button_release');
				$data['button_refund'] = $this->language->get('button_refund');
				$data['button_void'] = $this->language->get('button_void');
				$data['text_confirm_void'] = $this->language->get('text_confirm_void');
				$data['text_confirm_release'] = $this->language->get('text_confirm_release');
				$data['text_confirm_refund'] = $this->language->get('text_confirm_refund');

				$data['order_id'] = $this->request->get['order_id'];
				$data['user_token'] = $this->request->get['user_token'];

				return $this->load->view('extension/payment/paymongo_order', $data);
			}
		}
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/payment/paymongo')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		$data['entry_test_public_key'] = $this->language->get('entry_test_public_key');
		$data['entry_test_secret_key'] = $this->language->get('entry_test_secret_key');		
		$data['entry_live_public_key'] = $this->language->get('entry_live_public_key');
		$data['entry_live_secret_key'] = $this->language->get('entry_live_secret_key');

		if (!$this->request->post['payment_paymongo_test_public_key']) {
			$this->error['error_test_public_key'] = $this->language->get('error_test_public_key');
		}

		if (!$this->request->post['payment_paymongo_test_secret_key']) {
			$this->error['error_test_secret_key'] = $this->language->get('error_test_secret_key');
		}
		if (!$this->request->post['payment_paymongo_live_public_key']) {
			$this->error['error_live_public_key'] = $this->language->get('error_live_public_key');
		}

		if (!$this->request->post['payment_paymongo_live_secret_key']) {
			$this->error['error_live_secret_key'] = $this->language->get('error_live_secret_key');
		}

		return !$this->error;
	}
	
	public function generateWebhook()
	{
					$json = array();
					$this->load->language('extension/payment/paymongo');
					$this->load->model('setting/setting');
					
					$store_url=$this->request->server['HTTPS'] ? HTTPS_CATALOG : HTTP_CATALOG;
					
					$secret_key='';  
					if( $this->config->get('payment_paymongo_test') == 'test' ){
						$secret_key = $this->config->get('payment_paymongo_test_secret_key');
					} else if ( $this->config->get('payment_paymongo_test') == 'live' ){
						$secret_key = $this->config->get('payment_paymongo_live_secret_key');
					} 
					
					//attribute
					$attributes = array(
						'url' => $store_url.'index.php?route=extension/payment/paymongo_webhook',
						'events' => array("source.chargeable","payment.paid","payment.failed")		 
					);
					$payload = json_encode(
						array(
							'data' => array(
								'attributes' => $attributes,
							),
						)
					);
					//attribute
					
				$curl = curl_init();
				
				curl_setopt_array($curl, [
				  CURLOPT_URL => "https://api.paymongo.com/v1/webhooks",
				  CURLOPT_RETURNTRANSFER => true,
				  CURLOPT_ENCODING => "",
				  CURLOPT_MAXREDIRS => 10,
				  CURLOPT_TIMEOUT => 30,
				  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
				  CURLOPT_CUSTOMREQUEST => "POST",
				  CURLOPT_POSTFIELDS => $payload,
				  CURLOPT_HTTPHEADER => [
					"accept: application/json",
					"Authorization: Basic ".base64_encode($secret_key.':'),
					"content-type: application/json"
				  ],
				]);
				
				$response = json_decode(curl_exec($curl));
				$err = curl_error($curl);
				
				curl_close($curl);
				
				if ($err) {
				   $json['error']=$this->language->get('error_curl'). $err;
				} else {
								$body = json_decode(json_encode($response),true);
								$erroretrun='';
								//check webhook exist
								$payment_paymongo_webhook_url='';
								//check webhook exist
								if(isset($body['errors'])) {
										for ($i = 0; $i < count($body['errors']); $i++) {
											$erroretrun .=$body['errors'][$i]['detail'];
											//check webhook exist
											  if($body['errors'][$i]['code']=='resource_exists')
											{
												$payment_paymongo_webhook_url=$store_url.'index.php?route=extension/payment/paymongo_webhook';
												$payment_paymongo=array();
		
												$payment_paymongo['payment_paymongo_webhook_data']='';
		
												$payment_paymongo['payment_paymongo_webhook_url']=$payment_paymongo_webhook_url;
		
												$this->model_setting_setting->editSetting('payment_paymongo_webhook', $payment_paymongo);
		
												$json['success']=$this->language->get('text_webhook_url_generated');
												
												
											}	
											//check webhook exist
										}
										//check webhook exist
										if($payment_paymongo_webhook_url=='')
										{
											$json['error']=$erroretrun;
										}
										//check webhook exist
										
								}	
								else
								{
									
									if (array_key_exists('data', $body)
									&& array_key_exists('attributes', $body['data'])
									&& array_key_exists('status', $body['data']['attributes'])
									) {
										$payment_paymongo_webhook_data=json_encode($response);
										$payment_paymongo_webhook_url=$body['data']['attributes']['url'];
										
										
										$payment_paymongo=array();
										$payment_paymongo['payment_paymongo_webhook_data']=$payment_paymongo_webhook_data;
										$payment_paymongo['payment_paymongo_webhook_url']=$payment_paymongo_webhook_url;
										$this->model_setting_setting->editSetting('payment_paymongo_webhook', $payment_paymongo);
										$json['success']=$this->language->get('text_webhook_url_generated');
									  
									  }
								}
				 	
				}
		
		$this->response->addHeader('Content-Type: application/json');
		$this->response->setOutput(json_encode($json));		
				
	}
}
