<?php
// Text
$_['text_title']			 = 'BillEase via PayMongo <img src="/catalog/view/javascript/paymongo_billease.svg" style="max-width: 100px;"  alt="BillEase via PayMongo" />';


// Error
$_['error_below_minimum']	 = 'Amount cannot be less than P100.00';
$_['error_paymentstatus']	 = 'Something went wrong with the payment. Please try another payment method. If issue persist, contact support.';
$_['error_process_order']	 = 'There are an error processing your order. Please contact the shop administrator for help.';
$_['error_paymongo_site']	 = "<h3>Can't access site</h3><p>Timed out waiting for a response from the site <b>paymongo.com</b>.</p>";

