
<?php
class ControllerExtensionPaymentPaymongoAtome extends Controller {
	public function index()
	{
		$this->load->language('extension/payment/paymongo_atome');
		
		$data['button_continue'] = $this->language->get('button_continue');
		$data['text_loading'] = $this->language->get('text_loading');
		$data['SFWidget_css'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/css/SFWModal.min.css?1.0.0';

		$data['SFWidget_script'] = 'catalog/view/javascript/SFWidget-Modal/1.0.0/js/SFWModal.js?1.0.0';

		return $this->load->view('extension/payment/paymongo_atome', $data);
		
		}

	public function paymentSend()
	{			
				$json = array();
				if ((!$this->cart->hasProducts() && empty($this->session->data['vouchers'])) || (!$this->cart->hasStock() && !$this->config->get('config_stock_checkout'))) {
					$json['redirect']=$this->url->link('checkout/cart', '', true);
					$this->printJSON($json);
				}
				
				$this->load->language('extension/payment/paymongo_atome');
				$this->load->model('checkout/order');
				$this->load->model('localisation/country');
				$this->load->model('extension/payment/paymongo_atome');
				
				//if order undefined
				if(!isset($this->session->data['order_id']))
				{
					$json['error']  = $this->language->get('error_process_order');
					$this->printJSON($json);
				}
				
				//get current order
				$order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
				
				//Creating a data to send PaymentIntent
						$paymentIntendData = [
						"data" => [
							"attributes" => [
								"amount" => round($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false)*100), 
								"payment_method_allowed" => [
									"card", 'paymaya', 'atome', 'dob', 'billease'
								],  
								"currency" => "PHP",
								"description" => $order_info['store_name'] .' - Order ID:- '.$order_info['order_id']. '  - ' . date('Y-m-d H:i:s'),
								'metadata' => array(
									'agent' => 'cynder_opencart',
									'version' => '1.10.0',
							   )
							] 
						] 
					]; 
					
					//Update PaymentIntent data using secret API key
					$paymentIntendData = $this->model_extension_payment_paymongo_atome->CreatePaymentIntent($paymentIntendData);
			
					// check any errors in response datas
					if( isset($paymentIntendData->errors))
					{
						$json['error'] = $paymentIntendData->errors[0]->detail;
						if(@$paymentIntendData->errors[0]->code=='parameter_below_minimum')
						{
							$json['error']=$this->language->get('error_below_minimum');
						}
						$this->printJSON($json);
					}
					
					if($paymentIntendData->data->attributes->status=='awaiting_payment_method')
					{
									$this->model_extension_payment_paymongo_atome->updateOrderStatus(0,$order_info['order_id']);
									$message = 'paymongo_client_key:- '. $paymentIntendData->data->attributes->client_key; 
									$this->model_extension_payment_paymongo_atome->addOrderHistory($order_info['order_id'],15,0,$message);
									$message = 'paymongo_payment_intent_id:- '. $paymentIntendData->data->id; 
									$this->model_extension_payment_paymongo_atome->addOrderHistory($order_info['order_id'],15,0,$message);
					}
					//Сreating a data to send PaymentMethod
					$PaymentMethodData = [
					   "data" => [
							"attributes" => [ 
								"billing" => [
									"address" => [
										"line1" => $order_info['payment_address_1'], 
										"line2" => $order_info['payment_address_2'], 
										"city" => $order_info['payment_city'], 
										"state" => $order_info['payment_zone'], 
										"postal_code" => $order_info['payment_postcode'], 
										"country" => $this->model_localisation_country->getCountry($order_info['payment_country_id'])['iso_code_2'] 
									], 
									"name" => $order_info['firstname'] . ' ' . $order_info['lastname'], 
									"email" => substr($order_info['email'], 0, 255), 
									"phone" => substr($order_info['telephone'], 0, 20) 
								], 
								"type" => "atome" 
							] 
						] 
					]; 
					
					//Update PaymentIntent data using secret API key
					$PaymentMethodData = $this->model_extension_payment_paymongo_atome->CreatePaymentMethod($PaymentMethodData);
					
					// check any errors in response datas
					if(isset($PaymentMethodData->errors))
					{
						$json['error'] = $PaymentMethodData->errors[0]->detail;
						$this->printJSON($json);
					}
					
					//Сreating a data to send Attach To PaymentIntent
					$AttachToPaymentIntentData = [
						"data" => [
							"attributes" => [
								"payment_method" => $PaymentMethodData->data->id, 
								"client_key" => $paymentIntendData->data->attributes->client_key,
								'return_url' => $this->url->link('extension/payment/paymongo_atome/cynderpaymongocatchredirect&order=' . $order_info['order_id'] . '&intent=' . $paymentIntendData->data->id . '&agent=cynder_opencart&version=1.10.0', '', true)
							]
						]
					];
					
					//Update Attach To PaymentIntent data using client key
					$AttachToPaymentIntentData = $this->model_extension_payment_paymongo_atome->AttachToPaymentIntent($paymentIntendData->data->id,$AttachToPaymentIntentData);
						
					// check any errors in response datas
					if(isset($AttachToPaymentIntentData->errors))
					{
						$json['error'] = $AttachToPaymentIntentData->errors[0]->detail;
						$this->printJSON($json);
					}
					else
					{
						if($AttachToPaymentIntentData->data->attributes->status == "succeeded")
						{
							$body = json_decode(json_encode($AttachToPaymentIntentData),true);
							
							$paymentId = 'Payment ID:- '.$body['data']['attributes']['payments'][0]['id']; 
							$message = 'Payment ID:- '.$body['data']['attributes']['payments'][0]['id'];
							$paymongo_order_id=$this->model_extension_payment_paymongo_atome->addOrder($order_info, $paymentId );
							$this->model_extension_payment_paymongo_atome->addTransaction($paymongo_order_id, 'payment', $order_info);
							$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_paymongo_order_status_id'), $message, false);
							$json['redirect']=$this->url->link('checkout/success', '', true);
						}
						if($AttachToPaymentIntentData->data->attributes->status == "awaiting_next_action")
						{
							$json['redirect']=$AttachToPaymentIntentData->data->attributes->next_action->redirect->url;
						}
						
						$this->printJSON($json);
					}			
					

					
	}
	
	public function cynderpaymongocatchredirect()
	{
		$this->load->language('extension/payment/paymongo_atome');
		$this->load->model('checkout/order');
		$this->load->model('extension/payment/paymongo_atome');
		
		$paymentIntentId = $_GET['intent'];
		$orderId = $_GET['order'];
		
					//Update Attach To PaymentIntent data using client key
					$clientKey=$this->model_extension_payment_paymongo_atome->getKey('secret');
					$curl = curl_init();
					curl_setopt_array($curl, [
					  CURLOPT_URL => "https://api.paymongo.com/v1/payment_intents/".$paymentIntentId,
					  CURLOPT_RETURNTRANSFER => true,
					  CURLOPT_ENCODING => "",
					  CURLOPT_MAXREDIRS => 10,
					  CURLOPT_TIMEOUT => 30,
					  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
					  CURLOPT_CUSTOMREQUEST => "GET",
					  CURLOPT_HTTPHEADER => [
						"accept: application/json",
						"Authorization: Basic " . base64_encode( $clientKey ),
						"content-type: application/json"
					  ],
					]);
					$AttachToPaymentIntentData = json_decode(curl_exec($curl));
					curl_close($curl);
					
					if(empty($AttachToPaymentIntentData))
					{
			
						$AttachToPaymentIntentData = new stdClass();
			
						$AttachToPaymentIntentData->errors = [new stdClass()];
			
						$AttachToPaymentIntentData->errors[0]->detail =  $result->data->attributes->last_payment_error->failed_message;
						
					}
					
					// check any errors in response datas
					if(isset($AttachToPaymentIntentData->errors))
					{
						$this->session->data['error']=$AttachToPaymentIntentData->errors[0]->detail;
						$this->redirectPage($this->url->link('checkout/checkout', '', true));
					}
					else
					{
						if($AttachToPaymentIntentData->data->attributes->status == "succeeded" || $AttachToPaymentIntentData->data->attributes->status == "processing")
						{
							
							if ($AttachToPaymentIntentData->data->attributes->status === 'succeeded') {
								$order_info = $this->model_checkout_order->getOrder($orderId);
								
								$body = json_decode(json_encode($AttachToPaymentIntentData),true);
								$paymentId = 'Payment ID:- '.$body['data']['attributes']['payments'][0]['id']; 
								$message = 'Payment ID:- '.$body['data']['attributes']['payments'][0]['id']; 
								$paymongo_order_id=$this->model_extension_payment_paymongo_atome->addOrder($order_info, $paymentId );
								$this->model_extension_payment_paymongo_atome->addTransaction($paymongo_order_id, 'payment', $order_info);
								$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_paymongo_order_status_id'), $message, false);
								$this->redirectPage($this->url->link('checkout/success', '', true));
							
							
							}
							else if($AttachToPaymentIntentData->data->attributes->status == "awaiting_payment_method")
							{
								$this->session->data['error']= $this->language->get('error_paymentstatus');
								$this->redirectPage($this->url->link('checkout/checkout', '', true));
							}
						}
						else
						{
							$this->session->data['error']= $this->language->get('error_paymentstatus');
							$this->redirectPage($this->url->link('checkout/checkout', '', true));
						}
					}
		
	}
	
	private function printJSON($json)
	{
		$this->response->addHeader('Content-Type: application/json');
		exit(json_encode($json));
	}
	
	private function redirectPage($url)
	{ 
	?>
	<script language="javascript">window.location.href = "<?php echo $url;?>";</script>
	<?php 
	}

}
