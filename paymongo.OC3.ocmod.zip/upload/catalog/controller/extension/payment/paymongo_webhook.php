
<?php
class ControllerExtensionPaymentPaymongoWebhook extends Controller {
	public function index()
	{
		
		 $this->load->model('checkout/order');
		 $this->load->model('extension/payment/paymongo');
		 $payload = file_get_contents('php://input');
		 $webhook_call = json_decode($payload);
         if($webhook_call)
		 {
					 $call_type = $webhook_call->data->attributes->type;
					 $call_body = $webhook_call->data->attributes->data->attributes;
					 $resource_id = $webhook_call->data->attributes->data->id;
					 
					 $decoded = json_decode($payload, true);
					 $eventData = $decoded['data']['attributes'];
					 $resourceData = $eventData['data'];
					 
					 $validEventTypes = [
						'source.chargeable',
						'payment.paid',
						'payment.failed',
					];
					 
					 $clientKey='';  
					 if( $this->config->get('payment_paymongo_test') == 'test' ){
						 $clientKey = $this->config->get('payment_paymongo_test_secret_key');
					 } else if ( $this->config->get('payment_paymongo_test') == 'live' ){
						 $clientKey = $this->config->get('payment_paymongo_live_secret_key');
					 }
					 
					 if (in_array($eventData['type'], $validEventTypes)) { 
								
								if ($eventData['type'] === 'source.chargeable') {
										
										$sourceId = $resourceData['id'];
										
										$curl = curl_init();
										curl_setopt_array($curl, [
										CURLOPT_URL => "https://api.paymongo.com/v1/sources/".$resource_id,
										CURLOPT_RETURNTRANSFER => true,
										CURLOPT_ENCODING => "",
										CURLOPT_MAXREDIRS => 10,
										CURLOPT_TIMEOUT => 30,
										CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
										CURLOPT_CUSTOMREQUEST => "GET",
										CURLOPT_HTTPHEADER => [
											"Accept: application/json",
											"Authorization: Basic ".base64_encode($clientKey.':'),
											"Content-Type: application/json"
										],
										]);
								
										$source_details = json_decode(curl_exec($curl));
										$err = curl_error($curl);
										curl_close($curl);
										if($err!=''){
											$this->log->write("[PayMongo, Webhook] source.chargeable event - Failed to retrieve source - ".$err);
										}
										else
										{
											if($source_details->data->attributes->status != 'chargeable'){
												$this->log->write("[PayMongo, Webhook] source.chargeable event - Source ".$source_details->data->id." has status ".$source_details->data->attributes->status."- not chargeable");
											}
											else
											{
												parse_str(parse_url($source_details->data->attributes->redirect->success)["query"], $params);		
												$order_id=$params['order'];
												$order_info = $this->model_checkout_order->getOrder($order_id);
												if($order_info)
												{
												//create payment 
												  
												  $createPaymentPayload = array(
														'data' => array(
															'attributes' => array(
																'amount' =>round($this->currency->format($order_info['total'], $order_info['currency_code'], $order_info['currency_value'], false)*100),
																'currency' => $order_info['currency_code'],
																'description' => $order_info['store_name'] . ' - ' . $order_info['order_id'],
																'source' => array(
																	'id' => $source_details->data->id,
																	'type' => 'source'
																),
															),
														),
													);
													$createPaymentPayload = json_encode($createPaymentPayload);
													 // Create payment for source
													$curl = curl_init();
								
													curl_setopt_array($curl, [
													CURLOPT_URL => "https://api.paymongo.com/v1/payments",
													CURLOPT_RETURNTRANSFER => true,
													CURLOPT_ENCODING => "",
													CURLOPT_MAXREDIRS => 10,
													CURLOPT_TIMEOUT => 30,
													CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
													CURLOPT_CUSTOMREQUEST => "POST",
													CURLOPT_POSTFIELDS => $createPaymentPayload,
													CURLOPT_HTTPHEADER => [
														"Accept: application/json",
														"Authorization: Basic ".base64_encode($clientKey.':'),
														"Content-Type: application/json"
													],
													]); 
											
													$response = json_decode(curl_exec($curl));
													$err = curl_error($curl);
													curl_close($curl);
													if($err!=''){
																$this->log->write("Payment creation failed for: ".$source_details->data->id);
																die;
													}
													else
													{
															  $body = json_decode(json_encode($response),true);
															  if (isset($body['errors'])) {
																	$erroretrun='';
																	for ($i = 0; $i < count($body['errors']); $i++) {
																		$erroretrun .=$body['errors'][$i]['detail'];
																	}
																	$this->log->write($erroretrun);
																	die;
																}
																$status = $body['data']['attributes']['status'];	
																if ($status == 'paid') {
																	 $message = 'Payment ID:- '.$body['data']['id'];	
																	 $paymentId =$body['data']['id'];
																	 $paymongo_order_id=$this->model_extension_payment_paymongo->addOrder($order_info, $paymentId );
																	 $this->model_extension_payment_paymongo->addTransaction($paymongo_order_id, 'payment', $order_info);
																	 $this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_paymongo_order_status_id'), $message, false);								
																	 die;
																}
																if ($status == 'failed') 
																{
																	$message="Payment creation failed for: ".$source_details->data->id;
																	$this->model_checkout_order->addOrderHistory($order_info['order_id'], 10, $message, false);									    													$this->log->write("Payment failed - Order Id: ".$order_info['order_id']);
																	die;
																}
													
													}
													 // Create payment for source 	
												//create payment
											  }
											}
										
										}   
								
								}
								
								if ($eventData['type'] === 'payment.paid') {
									//payment paid
										
										
										
										 // Verify the payment with paymongo
											$curl = curl_init();
						
											curl_setopt_array($curl, [
											CURLOPT_URL => "https://api.paymongo.com/v1/payments/".$resource_id,
											CURLOPT_RETURNTRANSFER => true,
											CURLOPT_ENCODING => "",
											CURLOPT_MAXREDIRS => 10,
											CURLOPT_TIMEOUT => 30,
											CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
											CURLOPT_CUSTOMREQUEST => "GET",
											CURLOPT_HTTPHEADER => [
												"Accept: application/json",
												"Authorization: Basic ".base64_encode($clientKey.':'),
												"Content-Type: application/json"
											],
											]);
						
											$payment_details = json_decode(curl_exec($curl));
											$err = curl_error($curl);
											curl_close($curl);
											if($err!=''){
												
												$this->log->write("[PayMongo, Webhook] payment.paid event - Failed to retrieve payment object - ".$err);
												die;
											}
											else
											{
														//payment intent
																$intent_curl = curl_init();
																curl_setopt_array($intent_curl, [
																CURLOPT_URL => "https://api.paymongo.com/v1/payment_intents/".$payment_details->data->attributes->payment_intent_id,
																CURLOPT_RETURNTRANSFER => true,
																CURLOPT_ENCODING => "",
																CURLOPT_MAXREDIRS => 10,
																CURLOPT_TIMEOUT => 30,
																CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
																CURLOPT_CUSTOMREQUEST => "GET",
																CURLOPT_HTTPHEADER => [
																	"Accept: application/json",
																	"Authorization: Basic ".base64_encode($clientKey.':'),
																	"Content-Type: application/json"
																],
																]);
											
																$payment_intent_details = json_decode(curl_exec($intent_curl));
																$err = curl_error($curl);
																curl_close($intent_curl);
																if($err!=''){
																	$this->log->write("[PayMongo, Webhook] payment.paid event - Failed to retrieve payment intent - ".$err);
																	die;
																}
																else
																{
																	 
																	 $message = 'Payment ID:- '.$resourceData['id'];	
																	 $paymentId =$resourceData['id'];
																	 $Order_id=preg_replace('/[^0-9]/', '', $payment_intent_details->data->attributes->description);
																	 $order_info = $this->model_checkout_order->getOrder($order_id);
																	 if($order_info)
																	 {
																	 	$paymongo_order_id=$this->model_extension_payment_paymongo->addOrder($order_info, $paymentId);
																	 	$this->model_extension_payment_paymongo->addTransaction($paymongo_order_id, 'payment', $order_info);
																	 	$this->model_checkout_order->addOrderHistory($order_info['order_id'], $this->config->get('payment_paymongo_order_status_id'), $message, false);				}				
																	die;
																				
																
																}
														//payment intent
											
											}
											// Verify the payment with paymongo
								
								
									//payment paid
									
								}
								
								if ($eventData['type'] === 'payment.failed') {
										
										
										 // Verify the payment with paymongo
											$curl = curl_init();
						
											curl_setopt_array($curl, [
											CURLOPT_URL => "https://api.paymongo.com/v1/payments/".$resource_id,
											CURLOPT_RETURNTRANSFER => true,
											CURLOPT_ENCODING => "",
											CURLOPT_MAXREDIRS => 10,
											CURLOPT_TIMEOUT => 30,
											CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
											CURLOPT_CUSTOMREQUEST => "GET",
											CURLOPT_HTTPHEADER => [
												"Accept: application/json",
												"Authorization: Basic ".base64_encode($clientKey.':'),
												"Content-Type: application/json"
											],
											]);
						
											$payment_details = json_decode(curl_exec($curl));
											$err = curl_error($curl);
											curl_close($curl);
											if($err!=''){
												
												$this->log->write("[PayMongo, Webhook] payment.failed event - Failed to retrieve payment object - ".$err);
												die;
											}
											else
											{
														//payment intent
																$intent_curl = curl_init();
																curl_setopt_array($intent_curl, [
																CURLOPT_URL => "https://api.paymongo.com/v1/payment_intents/".$payment_details->data->attributes->payment_intent_id,
																CURLOPT_RETURNTRANSFER => true,
																CURLOPT_ENCODING => "",
																CURLOPT_MAXREDIRS => 10,
																CURLOPT_TIMEOUT => 30,
																CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
																CURLOPT_CUSTOMREQUEST => "GET",
																CURLOPT_HTTPHEADER => [
																	"Accept: application/json",
																	"Authorization: Basic ".base64_encode($clientKey.':'),
																	"Content-Type: application/json"
																],
																]);
											
																$payment_intent_details = json_decode(curl_exec($intent_curl));
																$err = curl_error($curl);
																curl_close($intent_curl);
																if($err!=''){
																	$this->log->write("[PayMongo, Webhook] payment.failed event - Failed to retrieve payment intent - ".$err);
																	die;
																}
																else
																{
																	$this->log->write("[processWebhook] event: payment.failed with payment intent ID  - ".$payment_details->data->attributes->payment_intent_id);										
																	$Order_id=preg_replace('/[^0-9]/', '', $payment_intent_details->data->attributes->description);
																	$order_info = $this->model_checkout_order->getOrder($order_id);
																	if($order_info)
																	{
																		$message="payment.failed with payment intent ID: ".$payment_details->data->attributes->payment_intent_id;
																		$this->model_checkout_order->addOrderHistory($order_info['order_id'], 10, $message, false);	
																	}
																	die;
																				
																
																}
														//payment intent
											
											}
											// Verify the payment with paymongo
								
								}
						
					 }	
				}
    }
}
