<?php



class ModelExtensionPaymentPaymongoGcash extends Model {



	public function getMethod($address, $total)

	{

		$status = true;



		$this->load->language('extension/payment/paymongo_gcash');



		$method_data = array();



		if ($status) {

			$method_data = array(

				'code' => 'paymongo_gcash',

				'title' => $this->language->get('text_title'),

				'terms' => '',

				'sort_order' => $this->config->get('payment_paymongo_gcash_sort_order')

			);

		}



		return $method_data;

	}

	public function updateOrderStatus($order_status_id, $order_id) {

		$this->db->query("UPDATE `" . DB_PREFIX . "order` SET order_status_id = '".$order_status_id."', date_modified = NOW() WHERE order_id = '" . (int)$order_id . "'");

	}
	
	public function addOrderHistory($order_id, $order_status_id,$notify,$message) {

		$this->db->query("INSERT INTO " . DB_PREFIX . "order_history SET order_id = '" . (int)$order_id . "', order_status_id = '".$order_status_id."', notify = '".$notify."', comment = '" . $this->db->escape($message) . "', date_added = NOW()");

	}
	
 

	private function getKey( $APIkey = 'public' )

	{

		$key = '';



		if( $this->config->get('payment_paymongo_test') == 'test' ){

			$key = $this->config->get('payment_paymongo_test_' . $APIkey . '_key');

		} else if ( $this->config->get('payment_paymongo_test') == 'live' ){

			$key = $this->config->get('payment_paymongo_live_' . $APIkey . '_key');

		}



		return $key;

	}
	


	private function curlRrequest($url, $key, $order_data = null, $method =  'POST' ) { 

		$this->load->language('extension/payment/paymongo_gcash');
		
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, 'https://api.paymongo.com/'.$url);
		$content_length = 0;
		if ($order_data) {
			$json = json_encode($order_data);
			$content_length = strlen($json);
			curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
			curl_setopt($curl, CURLOPT_POSTFIELDS, $json);
		}
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 0);
		curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
		curl_setopt($curl, CURLOPT_TIMEOUT, 10);
		curl_setopt(
				$curl, CURLOPT_HTTPHEADER, array(
			"Authorization: Basic " . base64_encode( $key ),
			"Content-Type: application/json",
			"Content-Length: " . $content_length
				)
		);		
		$result = json_decode(curl_exec($curl));

		curl_close($curl);



		if(empty($result))

		{

			$result = new stdClass();

			$result->errors = [new stdClass()];

			$result->errors[0]->detail = $this->language->get('error_paymongo_site');

		}



		return $result;

	}



	public function PaymentSourcesData( $order_data )

	{

		return $this->curlRrequest( 'v1/sources', $this->getKey( 'secret' ), $order_data, 'POST' );

	}
}

