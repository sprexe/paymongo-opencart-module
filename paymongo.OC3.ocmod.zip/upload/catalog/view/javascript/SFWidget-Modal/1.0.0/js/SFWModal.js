function SFWModal(_this) {
  _this.modal = document.createElement("div");
  _this.modal.className = "SFW_modal" + (_this.background ? " modal_bg" : "") + (/lg|md|xs|full/.test(_this.modalsize) ? " m-"+_this.modalsize : "");
  var body = document.body,
    modal = _this.modal,
    once = true,
    openStatus = false,
    bClass = body.className,
    modalOut,
    clickable = true,
    noIE9= "transition" in modal.style || "webkitTransition" in modal.style,
    transDur = noIE9?200:150;


  //start modalAnimate
  function modalAnimate() {


      //add sapce to right if overflow hidde
       modal.style.bottom = "0";body.style.overflowY = "auto";
       var ofWi = modal.offsetWidth, wWi=window.innerWidth;

         var modalPos = modal.querySelector(".modal_pos"),
         bottomSpace = window.innerHeight - modalPos.offsetHeight;
         if (bottomSpace>0) {
           bottomSpace < modalPos.offsetTop ? modalPos.style.marginTop = (bottomSpace/2) +"px" : "";
         }else {
            modalPos.style.marginTop = "0px"
         }

       bClass = (document.documentElement.clientWidth<wWi ? "oflowY " : "") + bClass.replace("oflowY ","");
       modal.clientWidth<ofWi&&!(ofWi<wWi) ?  (modal.style.right = "17px",ofWi = modal.offsetWidth) : "";
       modal.className = (modal.clientWidth<ofWi ? "oflowY " : "")  + modal.className.replace("oflowY ","");
       body.style.overflowY = ""; modal.style.bottom = "auto";

      var scl = 0, css = "scale("+scl+")";

    if (modalOut) {
      //create css for transforme
      var outMatch = modalOut.match(/top|right|bottom|left/i);

      if (outMatch) {
        //out from out side window
        var left = (outMatch[0] === "left" ? -modal.offsetWidth : outMatch[0] === "right" ? modal.offsetWidth : 0);
        var top = (outMatch[0] === "top" ? -modal.offsetHeight : outMatch[0] === "bottom" ? modal.offsetHeight : 0);
          css = "translate(" + left + "px," + top + "px)";
      } else {
        //out from id
        var outById = document.querySelector("#" + modalOut);
        if (outById) {
          var centerOfModal = modal.getBoundingClientRect().height / 2,
          outRect = outById.getBoundingClientRect();

           //zoom efect image  if outbyid tag name img get scale size
           var imgInModal = modal.getElementsByTagName("img");
           if (outById.tagName == "IMG"&&imgInModal[0]) {
            if(!openStatus) {
              modal.className += " img_zoom";
              outById.className += " hid_img";
              if(modal.offsetHeight - window.innerHeight<=0&&modal.style.right == "17px")modal.style.right = "";
            }
            centerOfModal = modal.getBoundingClientRect().height / 2;
            var imgRect = imgInModal[0].getBoundingClientRect();
            scl = imgRect.width > imgRect.height ? (outRect.width / imgRect.width) : (outRect.height / imgRect.height);

             centerOfModal = centerOfModal- ((centerOfModal-(imgRect.top+(imgRect.height/2))) * scl)
          }

          //get transform position
          var left = (outRect.left + outRect.width / 2) - (ofWi/ 2),
          top = ((outRect.top + outRect.height / 2)) - centerOfModal;

          css = "translate(" + left + "px," + top + "px) scale("+scl+")";
        }
      }

    }


    // add css to modal style

    function addTransform(tCss) {
      modal.style.webkittransform = tCss;
      modal.style.msTransform = tCss;
      modal.style.transform = tCss;
      outMatch!==null&&noIE9?modal.style.opacity = 0:"";
    }

    function startTransition() {
      body.className = bClass + " SFW_modal_trans";
      //transition supported
      if (noIE9) {
            modal.style.webkittransition = (openStatus&&outMatch!==null ? "cubic-bezier(0.47, 0.01, 0.27, 1.36) " : "") + "transform " + transDur + "ms, padding 0s, background 0s, opacity " + transDur + "ms";
            modal.style.transition = (openStatus&&outMatch!==null ? "cubic-bezier(0.47, 0.01, 0.27, 1.36) " : "") + "transform " + transDur + "ms, padding 0s, background 0s, opacity " + transDur + "ms";
            modal.style.webkittransform = "";
            modal.style.transform = "";
            modal.style.opacity = 1;
      }else {
        var fps=(transDur)/ 20,aL=Math.abs(left),aT=Math.abs(top),bL=aL/fps,bT =aT/fps,newScl=(1-scl)/fps;
        if (!openStatus) {
          aL=0;aT=0;scl=1;
        }

        var stop = 100 / fps,cout=0,
        zoom = setInterval(function () {
          modal.style.msTransform = "translate(" +( !aL ? 0 : (left<0?"-"+(aL):aL) )+ "px," +( !aT ? 0 :  (top<0?"-"+aT:aT) )+ "px)"+(!outMatch?" scale("+scl+")" : "");
          aL = parseFloat((aL +  (openStatus?-bL:bL)).toFixed(3));
          aT = parseFloat((aT +  (openStatus?-bT:bT)).toFixed(3));
          scl = parseFloat((scl +  (!openStatus?-newScl:newScl)).toFixed(3));
          cout +=stop;
         if (cout >= 100) {
              clearInterval(zoom);
              setTimeout(function(){modal.setAttribute("style", "")},100);

         }

        },fps)
      }

    }

    function endTransition(callBack) {
      setTimeout(function() {
        body.className = (openStatus ? "SFW_modal_open " : "") + bClass;
        modal.setAttribute("style", "");
        clickable = true;
        if (typeof(callBack) === "function") callBack();
      }, transDur)
    }


    //lunch transition and transorm function
    if (openStatus) { //close modal
      openStatus = false;
      startTransition();
      noIE9 ? addTransform(css) : "";
      endTransition(function() {
        if (outById) { //remove class, for imgae zoom
          for (var i = 0, a = [outById, modal]; i < a.length; i++) {
            a[i].className = a[i].className.replace(/ hid_img| img_zoom/, "");
          }
        }
        body.removeChild(modal);
      })
    } else { //open modal
      openStatus = true;
      addTransform(css);
      setTimeout(function() {
       startTransition();endTransition();
     }, 20);
    }




  } //end modalAnimate


  //start createModal
  function createModal(clickedEl) {
    var content = typeof(_this.content) === "function" ? _this.content(this) : _this.content;

    function ContentToObj(_html) 
    {

      var modalCont = document.createElement("div");
      modalCont.className = "modal_cont";

      //test elemetnt object
      if(typeof _html === 'object')
      {
        _html = _html[0] || _html;

        if(_html.tagName)
          modalCont.appendChild(_html);
        else
          modalCont.innerHTML = JSON.stringify(_html);
      }
      else
      {
        modalCont.innerHTML = _html;
      }

      //parse img src in modal for onload before open modal
      var imageElements = modalCont.querySelectorAll("img");

      (function loopImg(ind) 
      {
        if (imageElements.length == ind) 
          return appendModal();

        imageElements[ind].onload  = function() 
        {
          return loopImg(ind+1);
        }

        imageElements[ind].onerror = function() 
        {
          return loopImg(ind+1);
        }

      })(0);

      //parse iframe src in modal for onload before open modal
      var iframeElement = modalCont.querySelector("iframe");
      if(iframeElement)
      {
        var iframeLoading = document.createElement('div');
        iframeLoading.className = 'content-loading';
        iframeLoading.innerHTML = '<div></div><div></div>';
        modalCont.appendChild(iframeLoading);

        iframeElement.onload  = function() 
        {
          iframeLoading.parentElement.removeChild(iframeLoading);
        }
      }

      function appendModal() {
        loadModalParent.removeChild(loadModal);
        modal.innerHTML = "<div class=\"modal_pos\" >" +
          "<div class=\"modal_blk\">" +
          "<div class=\"modal_cls\"><i></i></div>" +
          "</div>" +
          "</div>";
        body.appendChild(modal);
        modal.getElementsByClassName("modal_blk")[0].appendChild(modalCont);
        modalAnimate();
        typeof(_this.callback) === "function" ? _this.callback(modal, clickedEl) : "";
      }

    }

    //loading tag add
    var loadModal = document.createElement("div"),loadModalParent = clickedEl;
    loadModal.className = "SFW_load_modal"
    loadModalParent.appendChild(loadModal);

    //try if content type ajaxe else query from document or string
    if (_this.request !== undefined && _this.request.responseText !== undefined) 
    {
      _this.request.onreadystatechange = function() 
      {
        if (this.readyState == 4 && this.status == 200)
        {
          content = this.responseText;
          ContentToObj(content);
        }
        else
        {
          ContentToObj('Request failed!');
        }
      }

    } 
    else
    {//if content as string

      try {//check content to query

        if (content == "" || content == undefined)
        {
          content = document.querySelector("#" + modalOut);

          if(content.tagName === "IMG")
          {
            clickedEl.parentNode.appendChild(loadModal);
            loadModalParent = clickedEl.parentNode;
            content = content.outerHTML
          }
          else 
          {
            content = null;
          }
        }
        else 
        {
          content = document.querySelector(content).innerHTML;
        }
      } 
      catch (e) {} finally
      {
        ContentToObj(content);
      }

    }
  }


  //-------targets-----//
  //close modal
  modal.onclick = function(e) {
    var cls = /modal_pos|SFW_modal|modal_cls/.test(e.target.className) || e.target.parentNode.className == "modal_cls";
    if (cls && clickable){clickable = false;  modalAnimate();}
  }

  if(this.query == undefined)
  {
    modalOut = _this.modalout;
    createModal(document.body);
  }
  else
  {
    //open modal
    document.addEventListener("click", function(e) {

      try {
        var query = _this.query.split(",")[0];
        query = document.querySelectorAll(query + "," + query + " *");
      } catch (e) {
        return console.error("Query undefined! SFWModal error");;
      }

      for (var i = 0; i < query.length; i++) {

        if (query[i] === e.target) {
          var ind = i;
          while (query[ind].parentNode.querySelector(_this.query) === null) ind--;
          modalOut = query[i].getAttribute("data-modalout");
          if (clickable){clickable = false; createModal(query[ind]);}
          break;
        }
      }
    }, false);
  }
  

  _this.modal.close = modalAnimate

  return _this.modal;
} //end modal
